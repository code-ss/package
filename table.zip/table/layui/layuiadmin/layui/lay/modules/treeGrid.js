/**
 @Name��treeGrid��״����
 @Author��beijiyi
 @version: 0.1
 ���Ƶ�ַ��https://gitee.com/beijiyi/tree_table_treegrid_based_on_layui
 ����demo��http://beijiyi.com/
 */
layui.config({
}).extend({
}).define(['laytpl', 'laypage', 'layer', 'form'], function(exports){
    "use strict";
    var $ = layui.$
        ,laytpl = layui.laytpl
        ,laypage = layui.laypage
        ,layer = layui.layer
        ,form = layui.form
        ,hint = layui.hint()
        ,device = layui.device()
        //�ⲿ�ӿ�
        ,table = {
            config: {//ȫ��������,���񼶱�
                indexName: 'lay_table_index' //�±�������
                ,cols:{//�ڵ㼶��ĸ����ֶ�
                    isCheckName: 'lay_is_checked' //ѡ��״̬��true��false��
                    ,isRadio:'lay_is_radio'//��ѡ״̬��true��false��
                    ,isOpen:'lay_is_open'//�Ƿ�չ���ڵ�
                    ,isShow:'lay_is_show'//�Ƿ���ʾ�ڵ�
                    ,level:'lay_level'//�ڵ�Ĳ㼶��ϵ������Ҫ���ã�
                    ,children:'children'//����¼��ı���

                    ,cheDisabled:'lay_che_disabled'//��ֹ��ѡ��true��false��
                    ,radDisabled:'lay_rad_disabled'//��ֹ��ѡ��true��false��

                    ,iconOpen:'lay_icon_open'//�򿪵�ͼ��
                    ,iconClose:'lay_icon_close'//�رյ�ͼ��
                    ,icon:'lay_icon'//Ҷ�ӽڵ�ͼ��
                }
                ,initWidth:{//Ĭ���п��ȶ���
                    checkbox: 48
                    ,space: 15
                    ,numbers: 40
                    ,radio:48
                }
            }
            /**
             * ��������
             *
             * �ṹͼʾ
             * cache{}                  ���棨����
             *      key['data']{}       ȫ�����ݻ��棨����
             *          key[list][]     �б����ݶ������飩
             *          key[map]{}      �б�����Map����Map��
             *          key[treeList][] ��״�ṹ�Ķ������飩
             *      key['cla']{}        ȫ���ѳ�ʼ������Calss�����ࣨע����Ⱦ���첽ִ�У�
             *          key['claIds'][] ȫ���Ѿ����ù���ʼ�������ı�����
             *          key[claObjs]{key[tableId]}  ȫ���Ѿ���ʼ���õ�cla����
             *
             */
            ,cache: {
                tableId:{
                    data:{
                        list:[]//�б�����
                        ,map:{}//�б�������idField��Ψһֵ��Ϊkey��Map����
                        ,treeList:[]//��״����
                        ,upIds:[]//���ڵ㼯��  ��һ���ⲿ����ǰ�ϸ��յ�һ�ε�˳��
                    }
                }
                ,cla:{
                    claIds:{
                        tableId:true
                    }
                    ,claObjs:{
                        tableId:{}
                    }
                }
                ,selectcode:{//�����ֵ仺��
                    demokey:[
                        {
                            key:{value:''}
                        }
                    ]
                }
            }
            ,index: layui.table ? (layui.table.index + 10000) : 0
            /**
             * ����ȫ����
             * @param options
             * @return {table}
             */
            ,set: function(options){
                var that = this;
                that.config = $.extend({}, that.config, options);
                return that;
            }
            /**
             * �¼�����
             * @param events
             * @param callback
             * @return {*}
             */
            ,on: function(events, callback){
                return layui.onevent.call(this, MOD_NAME, events, callback);
            }
            ,getClass:function (tableId) {
                return table.cache.cla.claObjs[tableId];;
            }
            ,pushClass:function (tableId,that) {
                table.cache.cla.claObjs[tableId]=that;
            }
            ,isCalss:function (tableId) {
                var ids=this.cache.cla.claIds||{};
                return  ids.hasOwnProperty(tableId)||false;
            }
            ,isClassYes:function (tableId) {
                var ids=this.cache.cla.claIds||{};
                return ids[tableId]||false;
            }
            ,pushClassIds:function (tableId,is) {
                this.cache.cla.claIds[tableId]=is;
            }
            ,setObj:function (tableId,key,o) {
                if(!this.obj[tableId])this.obj[tableId]={};
                this.obj[tableId][key]=o;
            }
            ,getObj:function (tableId, key) {
                return this.obj[tableId]?this.obj[tableId][key]:null;
            }
            /**
             * ��ȡ�б�����
             */
            ,getDataList:function (tableId) {
                if(table.cache[tableId]){
                    return table.cache[tableId].data.list;
                }
                return [];
            }
            /**
             * �����б�����
             */
            ,setDataList:function (tableId, list) {
                if(!table.cache[tableId])table.cache[tableId]={};
                if(!table.cache[tableId].data)table.cache[tableId].data={};
                if(!table.cache[tableId].data.list)table.cache[tableId].data.list=[];
                table.cache[tableId].data.list=list;
            }
            /**
             * ��ȡ�б�����
             */
            ,getDataMap:function (tableId) {
                if(table.cache[tableId]){
                    return table.cache[tableId].data.map;
                }
                return {};
            }
            /**
             * �����б�����
             */
            ,setDataMap:function (tableId, map) {
                if(!table.cache[tableId])table.cache[tableId]={};
                if(!table.cache[tableId].data)table.cache[tableId].data={};
                if(!table.cache[tableId].data.map)table.cache[tableId].data.map={};
                table.cache[tableId].data.map=map;
            }
            /**
             * ��ȡ��״����
             */
            ,getDataTreeList:function (tableId) {
                if(table.cache[tableId]){
                    return table.cache[tableId].data.treeList;
                }
                return [];
            }
            /**
             * ������״����
             */
            ,setDataTreeList:function (tableId, treeList) {
                if(!table.cache[tableId])table.cache[tableId]={};
                if(!table.cache[tableId].data)table.cache[tableId].data={};
                if(!table.cache[tableId].data.treeList)table.cache[tableId].data.treeList={};
                table.cache[tableId].data.treeList=treeList;
            }
            /**
             * ��ȡ���ڵ�����
             */
            ,getDataRootList:function (tableId) {
                if(table.cache[tableId]){
                    return table.cache[tableId].data.upIds||[];
                }
                return [];
            }
            /**
             * ���ø��ڵ�����
             */
            ,setDataRootList:function (tableId, rootList) {
                if(!table.cache[tableId])table.cache[tableId]={};
                if(!table.cache[tableId].data)table.cache[tableId].data={};
                if(!table.cache[tableId].data.upIds)table.cache[tableId].data.upIds=[];
                table.cache[tableId].data.upIds=rootList;
            }
            /**
             * ��ʼ��
             * @param filter
             * @param settings
             * @return {table}
             */
            ,init:function (filter, settings) {
                settings = settings || {};
                var that = this
                    ,elemTable = filter ? $('table[lay-filter="'+ filter +'"]') : $(ELEM + '[lay-data]')
                    ,errorTips = 'Table element property lay-data configuration item has a syntax error: ';
                //�������ݱ���
                elemTable.each(function(){
                    var othis = $(this), tableData = othis.attr('lay-data');
                    try{
                        tableData = new Function('return '+ tableData)();
                    } catch(e){
                        hint.error(errorTips + tableData)
                    }
                    var cols = [], options = $.extend({
                        elem: this
                        ,cols: []
                        ,data: []
                        ,skin: othis.attr('lay-skin') //���
                        ,size: othis.attr('lay-size') //�ߴ�
                        ,even: typeof othis.attr('lay-even') === 'string' //ż���б���
                    }, table.config, settings, tableData);

                    filter && othis.hide();

                    //��ȡ��ͷ����
                    othis.find('thead>tr').each(function(i){
                        options.cols[i] = [];
                        $(this).children().each(function(ii){
                            var th = $(this), itemData = th.attr('lay-data');

                            try{
                                itemData = new Function('return '+ itemData)();
                            } catch(e){
                                return hint.error(errorTips + itemData)
                            }

                            var row = $.extend({
                                title: th.text()
                                ,colspan: th.attr('colspan') || 0 //�е�Ԫ��
                                ,rowspan: th.attr('rowspan') || 0 //�е�Ԫ��
                            }, itemData);

                            if(row.colspan < 2) cols.push(row);
                            options.cols[i].push(row);
                        });
                    });

                    //��ȡ��������
                    othis.find('tbody>tr').each(function(i1){
                        var tr = $(this), row = {};
                        //����������ֶ���
                        tr.children('td').each(function(i2, item2){
                            var td = $(this)
                                ,field = td.data('field');
                            if(field){
                                return row[field] = td.html();
                            }
                        });
                        //���δ�����ֶ���
                        layui.each(cols, function(i3, item3){
                            var td = tr.children('td').eq(i3);
                            row[item3.field] = td.html();
                        });
                        options.data[i1] = row;
                    });
                    table.render(options);
                });

                return that;
            }
            /**
             * ��Ⱦ��ڷ�����������ڣ�
             */
            ,render:function (options) {
                table.pushClassIds(options.id);
                var inst = new Class(options);
                return thisTable.call(inst);
            }
            /**
             * ��Ӧ�ı��������ɺ�ִ��(���������ã���ʹ��parseData����)
             * @param tableId
             * @param fn
             */
            ,ready:function (tableId,fn) {
                var is=false;
                var myDate=new Date();
                function isReady() {
                    if(tableId){
                        var that=table.getClass(tableId);
                        if(that&&that.hasOwnProperty('layBody')){
                            fn(that);
                            is=true;
                        }else{
                            var myDate2=new Date();
                            var i=myDate2.getTime()-myDate.getTime();
                            if(i<=(1000*10)&&!is){//����10���˳�
                                setTimeout(isReady,50);
                            }
                        }
                    }
                }
                if(tableId&&fn){
                    setTimeout(isReady,50);
                }
            }
            /**
             * ��ȡ����ѡ�м�¼
             * @param tableId
             * @return {{data: Array, isAll: boolean}}
             */
            ,checkStatus:function (tableId) {
                var nums = 0
                    ,invalidNum = 0
                    ,arr = []
                    ,data = table.getDataList(tableId) || [];
                //����ȫѡ����
                layui.each(data, function(i, item){
                    if(item.constructor === Array){
                        invalidNum++; //��Ч���ݣ�����ɾ����
                        return;
                    }
                    if(item[table.config.cols.isCheckName]){
                        nums++;
                        arr.push(table.clearCacheKey(item));
                    }
                });
                return {
                    data: arr //ѡ�е�����
                    ,isAll: data.length ? (nums === (data.length - invalidNum)) : false //�Ƿ�ȫѡ
                };
            }
            /**
             * ���ñ���ѡ״̬
             * @param tableId
             * @param value     ��ֵ����ʱΪ���ò���
             * @returns {*}
             */
            ,setCheckStatus:function(tableId, fildName, ids){
                var retObj=null;
                var that=table.getClass(tableId)
                    ,invalidNum = 0
                    ,arr = []
                    ,data = table.getDataList(tableId) || []
                    ,childs = that.layBody.find('input[name="'+TABLE_CHECKBOX_ID+'"]')//��ѡ��
                ;
                if(fildName&&ids){//����ѡ��
                    var idsarr=ids.split(',');
                    idsarr.forEach(function (o) {
                        var temo=null;
                        data.forEach(function (e) {
                            var b1=e[fildName]+"";
                            var b2=o+"";
                            if(b1==b2){
                                temo=e;
                                return;
                            };
                        });
                        if(temo){
                            var v=temo[table.config.indexName];
                            that.layBody.find('input[name="'+TABLE_CHECKBOX_ID+'"][value="'+v+'"]').prop("checked",true);
                            that.setCheckData(v, true);
                        }
                    });
                    that.syncCheckAll();
                    that.renderForm('checkbox');
                }
                return retObj;
            }
            /**
             * ����ѡ״̬
             * @param tableId
             * @param value     ��ֵ����ʱΪ���ò���
             * @returns {*}
             */
            ,radioStatus:function (tableId) {
                var that=table.getClass(tableId);
                var retObj=null;
                var nums = 0
                    ,invalidNum = 0
                    ,arr = []
                    ,data = table.getDataList(tableId) || [];
                var v=that.layBody.find("input[name='"+TABLE_RADIO_ID+"']:checked").val();
                v=parseInt(v);
                data.forEach(function (e) {
                    if(e[table.config.indexName]==v){
                        retObj=e;
                    };
                });
                return table.clearCacheKey(retObj);
            }
            /**
             * ���ñ���ѡ״̬
             * @param tableId
             * @param value     ��ֵ����ʱΪ���ò���
             * @returns {*}
             */
            ,setRadioStatus:function (tableId,fildName,value) {
                var that=table.getClass(tableId);
                var retObj=null;
                var nums = 0
                    ,invalidNum = 0
                    ,arr = []
                    ,data = table.getDataList(tableId) || [];

                if(fildName&&value){//����ѡ��
                    data.forEach(function (e) {
                        var b1=e[fildName]+"";
                        var b2=value+"";
                        if(b1==b2){
                            retObj=e;
                            return;
                        };
                    });

                    if(retObj){
                        var v=retObj[table.config.indexName];
                        that.layBody.find("input:radio[name='"+TABLE_RADIO_ID+"'][value='"+v+"']").prop("checked",true);
                        form.render('radio');
                    }
                }
                return retObj;
            }
            /**
             * �����ʱKey
             * @param data
             * @return {*}
             */
            ,clearCacheKey:function (data) {
                data = $.extend({}, data);
                delete data[table.config.cols.isCheckName];
                delete data[table.config.indexName];
                return data;
            }
            /**
             * ˢ������
             * @param id
             * @param options
             * @return {*}
             */
            ,query:function (tableId, options) {
                var that= table.getClass(tableId);
                that.renderTdCss();
                if(that.config.data && that.config.data.constructor === Array) delete that.config.data;
                that.config = $.extend({}, that.config, options);
                that.pullData(that.page, that.loading());
            }
            /**
             * �˷���Ϊ����������Ⱦ��������ˢ�·�����
             * @param id
             * @param options
             */
            ,reload:function (tableId, options) {
                var config = thisTable.config[tableId];
                options = options || {};
                if(!config) return hint.error('The ID option was not found in the table instance');
                if(options.data && options.data.constructor === Array) delete config.data;
                return table.render($.extend(true, {}, config, options));
            }
            /**
             * ����һ�л��������
             * @param tableId   ����id
             * @param index     �ڵڼ���λ�ò��루��0��ʼ��
             * @param data      ����
             * @returns {*}
             */
            ,addRow:function (tableId, index, data) {
                var that=table.getClass(tableId)
                    ,options=that.config
                    ,uo = []//�����ڵ�
                    ,treeList=table.getDataTreeList(tableId)
                    ,list = table.getDataList(tableId) || [];
                that.resetData(data);
                //���뵽���ڵ����
                list.splice(index,0,data);//���»���
                table.kit.restNumbers(list);//�����±�
                table.setDataMap(tableId,that.resetDataMap(list));//����map
                if(options.isTree){//�����㼶
                    //1����������  2������treeObj 3���㼶
                    var uo=that.treeFindUpData(data);
                    if(uo) {
                        var clist=uo.children;
                        uo.children.push(data);
                        data[table.config.cols.level]=uo[table.config.cols.level]+1;
                    }else{
                        data[table.config.cols.level]=1;
                        treeList.push(data);
                    }
                }
                //����html
                var tds=that.renderTr(data,data[table.config.indexName]);
                var trs='<tr data-index="'+ data[table.config.indexName] +'"'+that.renderTrUpids(data)+'>'+ tds.join('') + '</tr>';
                if(index==0){//�ڵ�һ��λ�ò���
                    var  tbody=that.layBody.find('table tbody');
                    $(tbody).prepend(trs);
                    that.layBody.find(".layui-none").remove();
                }else{
                    var o=that.layBody.find('[data-index='+(index-1)+']');//���ڵ�dom��
                    $(o).after(trs);
                }
                that.renderForm();
                if(options.isPage)that.renderPage(that.config.page.count+1);//��ҳ��Ⱦ
                that.restNumbers();
                that.events();
                if(options.isTree) {//չ���ڵ�
                    that.treeNodeOpen(uo, true);
                    that.renderTreeConvertShowName(uo);
                }
            }
            /**
             * ɾ��һ�л��������
             * ���������״��ɾ���Լ����ӽڵ㣩
             * @param tableId
             * @param data��1�����飻2������
             */
            ,delRow:function (tableId, data) {
                //1��ҳ����� 2���������
                var that=table.getClass(tableId)
                    ,options=that.config
                    ,list=table.getDataList(tableId);
                var sonList=[];//��Ҫɾ��������
                var delIds={};//��Ҫɾ��������map
                var delDatas=[];
                var upDelDatas=[];//ȫ����ɾ���ڵ�ĸ��ڵ㣨�����۵���
                if(!that||!data)return;
                if(table.kit.isArray(data)){//�����飬ɾ�����
                    delDatas=data;
                }else{
                    delDatas[0]=data;
                }
                delDatas.forEach(function(temo) {//��¼ȫ�����ڵ�
                    var uo=that.treeFindUpData(temo);
                    if(uo){
                        upDelDatas.push(uo);
                    }
                });
                sonList=options.isTree?table.treeFindSonList(that.config.id,delDatas):delDatas;
                sonList.forEach(function (temo) {//ҳ��Ԫ�ش���
                    var index=temo[table.config.indexName];
                    delIds[index]=index;//���ô�ɾ����id����
                    var tr = that.layBody.find('tr[data-index="'+ index +'"]');
                    tr.remove();
                });
                that.restNumbers();//���ݴ���
                var newList=[];//�ع�һ���µ�����
                for (var i=0,len=list.length;i<len;i++) {
                    var isP=true;
                    var temo1=null;
                    sonList.forEach(function (temo) {
                        if (temo[table.config.indexName] === list[i][table.config.indexName]) {
                            isP = false;
                        }
                    });
                    if(isP){
                        newList.push(list[i]);
                    }
                }
                table.kit.restNumbers(newList);//�±����±��
                table.setDataList(tableId,newList);//����list
                table.setDataMap(tableId,that.resetDataMap(newList));//����map
                table.setDataTreeList(tableId,that.resetDataTreeList(newList,table.getDataRootList(tableId)));//�������ṹ
                upDelDatas.forEach(function(temo) {//���������ڵ�
                    that.renderTreeConvertShowName(temo);
                });
                if(options.isPage)that.renderPage(that.config.page.count-Object.keys(delIds).length);//��ҳ��Ⱦ
                that.events();//����ע���¼�
            }
            /**
             * ����ָ���ļ�¼
             * @param obj
             * @param index
             */
            ,updateRow:function (tableId,obj) {
                var that=table.getClass(tableId);
                if(!that||!obj)return;
                var id=obj[that.config.idField];
                //���»�������
                var maps=table.getDataMap(tableId);
                var thisobj=maps[id];
                if(thisobj){
                    $.extend(thisobj, obj);
                }else{
                    return;
                }
                //����ҳ��
                var oi=thisobj[table.config.indexName];
                var  tds=that.renderTr(thisobj,oi);
                var tr=that.layBody.find('tr[data-index='+oi+']');
                $(tr).html(tds);
            }
            ,treeNodeOpen:function (tableId,o, isOpen) {
                var that=table.getClass(tableId);
                if(!that||!o)return;
                that.treeNodeOpen(o,isOpen);
            }
            /**
             * �۵���չ��ȫ��(Ĭ��Ϊչ��ȫ���ڵ�)
             * @param tableId
             * @param isOpen    չ�������۵���Ĭ��ֵΪtrue չ����
             */
            ,treeOpenAll:function (tableId,isOpen) {
                var that=table.getClass(tableId);
                if(!that)return;
                if(isOpen===undefined){isOpen=true;}
                var list=table.getDataList(tableId);
                if(!list)return;
                list.forEach(function (temo) {
                    that.treeNodeOpen(temo,isOpen);
                });
            }
            /**
             * ��ȡȫ����Ҫ�ӽڵ���󼯺�
             * @param data����������
             */
            ,treeFindSonList:function (tableId,data) {
                var that=table.getClass(tableId);
                if(!that||!data)return [];
                var delDatas=[];
                var sonList=[];//��Ҫɾ��������
                var delIds={};//��Ҫɾ��������map
                if(table.kit.isArray(data)){//�����飬ɾ�����
                    delDatas=data;
                }else{
                    delDatas[0]=data;
                }
                delDatas.forEach(function (temo) {
                    if(temo.children.length>0){
                        var temSonList=that.treeFindSonData(temo);
                        temSonList.forEach(function (temii) {
                            if(!delIds[temii[table.config.indexName]]){
                                sonList.push(temii);
                                delIds[temii[table.config.indexName]]=temii[table.config.indexName];
                            }
                        });
                    }
                    sonList.push(temo);
                    delIds[temo[table.config.indexName]]=temo[table.config.indexName];
                });
                return sonList;
            }
            ,treeFindUpDatas:function (tableId, o) {
                var that=table.getClass(tableId);
                if(!that||!o)return [];
                return that.treeFindUpDatas(o);
            }
            ,treeFindUpData:function (tableId, o) {
                var that=table.getClass(tableId);
                if(!that||!o)return [];
                return that.treeFindUpData(o);
            }
            /**
             * ��ȡȫ����Ҫ�ӽڵ�id����
             * @param data����������
             */
            ,treeFindSonIds:function (tableId,data) {
                var delIds=[];
                var sonList=table.treeFindSonList(tableId,data);
                sonList.forEach(function (temo) {
                    delIds.push([table.config.indexName]);
                });
                return delIds;
            }
            /**
             * ��ȡȫ����id�ֶμ���
             * @param tableId
             * @param data
             * @returns {Array}
             */
            ,treeFindSonIdFields:function (tableId,data) {
                var idField=[];
                var that=table.getClass(tableId);
                var sonList=table.treeFindSonList(tableId,data);
                sonList.forEach(function (temo) {
                    idField.push(temo[that.config.idField]);
                });
                return idField;
            }
            ,treeIconRender:function (tableId, o) {
                var that=table.getClass(tableId);
                if(!that||!o)return [];
                return that.treeIconRender(o,false);
            }
            /**
             * ���߷�������
             */
            ,kit:{
                isArray:function (o) {
                    return Object.prototype.toString.call(o) === '[object Array]';
                }
                ,isNumber:function (val){
                    var regPos = /^\d+(\.\d+)?$/; //�Ǹ�������
                    var regNeg = /^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/; //��������
                    if(regPos.test(val) || regNeg.test(val)){
                        return true;
                    }else{
                        return false;
                    }

                }
                ,restNumbers:function (list) {
                    if(!list)return;
                    var i=0;
                    list.forEach(function (o) {
                        o[table.config.indexName]=i;
                        i++;
                    });
                }
            }
        }
        //������ǰʵ��
        ,thisTable = function(){
            var that = this
                ,options = that.config
                ,id = options.id;
            id && (thisTable.config[id] = options);
            return {
                reload: function(options){
                    that.reload.call(that, options);
                }
                ,config: options
            }
        }
        //�ַ�����
        ,MOD_NAME = 'treeGrid', ELEM = '.layui-table', THIS = 'layui-this', SHOW = 'layui-show', HIDE = 'layui-hide', DISABLED = 'layui-disabled', NONE = 'layui-none'
        ,ELEM_VIEW = 'layui-table-view', ELEM_HEADER = '.layui-table-header', ELEM_BODY = '.layui-table-body', ELEM_MAIN = '.layui-table-main', ELEM_FIXED = '.layui-table-fixed', ELEM_FIXL = '.layui-table-fixed-l', ELEM_FIXR = '.layui-table-fixed-r', ELEM_TOOL = '.layui-table-tool', ELEM_PAGE = '.layui-table-page', ELEM_SORT = '.layui-table-sort', ELEM_EDIT = 'layui-table-edit', ELEM_HOVER = 'layui-table-hover'
        ,TABLE_RADIO_ID='table_radio_',TABLE_CHECKBOX_ID='layTableCheckbox'
        ,ELEM_FILTER='.layui-table-filter'
        ,TREE_ID='treeId',TREE_UPID='treeUpId',TREE_SHOW_NAME='treeShowName',TREE_KEY_MAP='tree_key_map'
        //thead����ģ��
        ,TPL_HEADER = function(options){
            var rowCols = '{{#if(item2.colspan){}} colspan="{{item2.colspan}}"{{#} if(item2.rowspan){}} rowspan="{{item2.rowspan}}"{{#}}}';
            options = options || {};
            return ['<table cellspacing="0" cellpadding="0" border="0" class="layui-table" '
                ,'{{# if(d.data.skin){ }}lay-skin="{{d.data.skin}}"{{# } }} {{# if(d.data.size){ }}lay-size="{{d.data.size}}"{{# } }} {{# if(d.data.even){ }}lay-even{{# } }}>'
                ,'<thead>'
                ,'{{# layui.each(d.data.cols, function(i1, item1){ }}'
                ,'<tr>'
                ,'{{# layui.each(item1, function(i2, item2){ }}'
                ,'{{# if(item2.fixed && item2.fixed !== "right"){ left = true; } }}'
                ,'{{# if(item2.fixed === "right"){ right = true; } }}'
                ,function(){
                    if(options.fixed && options.fixed !== 'right'){
                        return '{{# if(item2.fixed && item2.fixed !== "right"){ }}';
                    }
                    if(options.fixed === 'right'){
                        return '{{# if(item2.fixed === "right"){ }}';
                    }
                    return '';
                }()
                ,'<th data-field="{{ item2.field||i2 }}" {{# if(item2.minWidth){ }}data-minwidth="{{item2.minWidth}}"{{# } }} '+ rowCols +' {{# if(item2.unresize){ }}data-unresize="true"{{# } }}>'
                ,'<div class="layui-table-cell laytable-cell-'
                ,'{{# if(item2.colspan > 1){ }}'
                ,'group'
                ,'{{# } else { }}'
                ,'{{d.index}}-{{item2.field || i2}}'
                ,'{{# if(item2.type !== "normal"){ }}'
                ,' laytable-cell-{{ item2.type }}'
                ,'{{# } }}'
                ,'{{# } }}'
                ,'" {{#if(item2.align){}}align="{{item2.align}}"{{#}}}>'
                ,'{{# if(item2.type === "checkbox"){ }}' //��ѡ��
                ,'<input type="checkbox" name="layTableCheckbox" lay-skin="primary" lay-filter="layTableAllChoose">'
                ,'{{# } else { }}'
                ,'<span>{{item2.title||""}}</span>'
                ,'{{# if(!(item2.colspan > 1) && item2.sort){ }}'
                ,'<span class="layui-table-sort layui-inline"><i class="layui-edge layui-table-sort-asc"></i><i class="layui-edge layui-table-sort-desc"></i></span>'
                ,'{{# } }}'
                ,'{{# } }}'
                ,'</div>'
                ,'</th>'
                ,(options.fixed ? '{{# }; }}' : '')
                ,'{{# }); }}'
                ,'</tr>'
                ,'{{# }); }}'
                ,'</thead>'
                ,'</table>'].join('');
        }
        /**
         * ���ڹ�������
         */
        ,TPL_FILTER = function(options){
        }
        //tbody����ģ��
        ,TPL_BODY = ['<table cellspacing="0" cellpadding="0" border="0" class="layui-table" '
            ,'{{# if(d.data.skin){ }}lay-skin="{{d.data.skin}}"{{# } }} {{# if(d.data.size){ }}lay-size="{{d.data.size}}"{{# } }} {{# if(d.data.even){ }}lay-even{{# } }}>'
            ,'<tbody></tbody>'
            ,'</table>'].join('')
        //��ģ��
        ,TPL_MAIN = ['<div class="layui-form layui-border-box {{d.VIEW_CLASS}}" lay-filter="LAY-table-{{d.index}}" style="{{# if(d.data.width){ }}width:{{d.data.width}}px;{{# } }} {{# if(d.data.height){ }}height:{{d.data.height}}px;{{# } }}">'

            ,'{{# if(d.data.toolbar){ }}'
            ,'<div class="layui-table-tool"></div>'
            ,'{{# } }}'

            ,'<div class="layui-table-box">'
            ,'{{# var left, right; }}'
            ,'<div class="layui-table-header">'
            ,TPL_HEADER()
            ,'</div>'
            ,'<div class="layui-table-filter">'
            ,TPL_FILTER()
            ,'</div>'
            ,'<div class="layui-table-body layui-table-main">'
            ,TPL_BODY
            ,'</div>'

            ,'{{# if(left){ }}'
            ,'<div class="layui-table-fixed layui-table-fixed-l">'
            ,'<div class="layui-table-header">'
            ,TPL_HEADER({fixed: true})
            ,'</div>'
            ,'<div class="layui-table-body">'
            ,TPL_BODY
            ,'</div>'
            ,'</div>'
            ,'{{# }; }}'

            ,'{{# if(right){ }}'
            ,'<div class="layui-table-fixed layui-table-fixed-r">'
            ,'<div class="layui-table-header">'
            ,TPL_HEADER({fixed: 'right'})
            ,'<div class="layui-table-mend"></div>'
            ,'</div>'
            ,'<div class="layui-table-body">'
            ,TPL_BODY
            ,'</div>'
            ,'</div>'
            ,'{{# }; }}'
            ,'</div>'

            ,'{{# if(d.data.isPage){ }}'
            ,'<div class="layui-table-page">'
            ,'<div id="layui-table-page{{d.index}}"></div>'
            ,'</div>'
            ,'{{# } }}'

            /*,'<style>'
            ,'{{# layui.each(d.data.cols, function(i1, item1){'
            ,'layui.each(item1, function(i2, item2){ }}'
            ,'.laytable-cell-{{d.index}}-{{item2.field||i2}}{ '
            ,'{{# if(item2.width){ }}'
            ,'width: {{item2.width}}px;'
            ,'{{# } }}'
            ,' }'
            ,'{{# });'
            ,'}); }}'
            ,'</style>'*/
            ,'</div>'].join('')
        ,_WIN = $(window)
        ,_DOC = $(document)

        //������
        ,Class = function(options){
            var that = this;
            that.index = ++table.index;
            that.config = $.extend({}, that.config, table.config, options);
            that.configFirst = $.extend({}, that.config, table.config, options);
            that.render();
            table.pushClass(options.id,that);
        };
    /**
     * ������Ϊ���ԣ�Ĭ�����ã�
     */
    Class.prototype.config = {
        limit: 10 //ÿҳ��ʾ������
        ,loading: true //��������ʱ���Ƿ���ʾloading
        ,cellMinWidth: 60 //���е�Ԫ��Ĭ����С����
        ,heightRemove:[]//�ǹ̶��߶�����£����������ĸ߶�
        ,text: {
            none: '<img src="http://172.28.2.2/nxqzf2/11515e9aeedab8ba92667778f3f887d4.png?Expires=1563940057&OSSAccessKeyId=cm49tWg0zDLFWojK&Signature=e4kNLI/uq4FdGtFIPINxKDwWLVc%3D" style="padding-top: 10px">'
        }
        ,isFilter:false//�Ƿ������ڹ���
        ,method:'post'//Ĭ����post��ʽ�����̨
        ,radDisabledNum:0//��ֹ��ѡ�ļ�¼��
        ,cheDisabledNum:0//��ֹ��ѡ�ļ�¼��
        //�����ͼ��
        ,branch: ['', ''] //���ڵ� ['&#xe622;', '&#xe624;'] 
        ,leaf: '' //Ҷ�ڵ� '&#xe621;' 
        ,iconOpen:true//Ĭ�Ͽ������ڵ�ͼ��
        ,isOpenDefault:true//Ĭ��չ�������۵��ڵ�
        ,parseData:null//�������ݺ�Ļص�����
        ,onClickRow:null//�е����¼�
        ,onDblClickRow:null//��˫���¼�
        ,onBeforeCheck:null//��ѡǰ�¼�
        ,onCheck:null//��ѡ�¼�  (obj ����,checked ѡ��״̬,isAll �Ƿ�ȫѡ)
        ,onRadio:null//��ѡ�¼�  ����
        ,isTree:true//Ĭ��Ϊ������
        ,isPage:false//����ҳ
        ,height:'100%'//Ĭ�ϸ߶�100%
    };
    Class.prototype.configFirst={};//ҳ�涨��ʱԭʼ����
    //������Ⱦ
    Class.prototype.render = function(){
        var that = this
            ,options = that.config;
        options.elem = $(options.elem);
        options.where = options.where || {};
        options.id = options.id || options.elem.attr('id');
        that.test();
        //����������Զ����ʽ
        options.request = $.extend({
            pageName: 'page'
            ,limitName: 'limit'
        }, options.request)
        //��Ӧ���ݵ��Զ����ʽ
        options.response = $.extend({
            statusName: 'code'
            ,statusCode: 0
            ,msgName: 'msg'
            ,dataName: 'data'
            ,countName: 'count'
        }, options.response);
        //��� page ���� laypage ����
        if(typeof options.page === 'object'){
            options.limit = options.page.limit || options.limit;
            options.limits = options.page.limits || options.limits;
            that.page = options.page.curr = options.page.curr || 1;
            delete options.page.elem;
            delete options.page.jump;
        }
        if(!options.elem[0]) return that;
        that.columnWidthInit();//�п��ȼ���
        //��ʼ�������Ԫ��
        var othis = options.elem
            ,hasRender = othis.next('.' + ELEM_VIEW)
            //������
            ,reElem = that.elem = $(laytpl(TPL_MAIN).render({
                VIEW_CLASS: ELEM_VIEW
                ,data: options
                ,index: that.index //����
            }));
        options.index = that.index;
        //�������Ԫ��
        hasRender[0] && hasRender.remove(); //����Ѿ���Ⱦ����Rerender
        othis.after(reElem);
        that.renderTdCss();
        //��������
        that.layHeader = reElem.find(ELEM_HEADER);  //��ͷ
        that.layMain = reElem.find(ELEM_MAIN);//��������
        that.layBody = reElem.find(ELEM_BODY);//��������
        that.layFixed = reElem.find(ELEM_FIXED);//��������
        that.layFixLeft = reElem.find(ELEM_FIXL);//�󸡶�
        that.layFixRight = reElem.find(ELEM_FIXR);//�и���
        that.layTool = reElem.find(ELEM_TOOL);//����������
        that.layPage = reElem.find(ELEM_PAGE);//��ҳ����
        that.layFilter=reElem.find(ELEM_FILTER);//���ڹ�����������
        that.layTool.html(
            laytpl($(options.toolbar).html()||'').render(options)
        );
        if(options.height){
            that.tableHeight();//����߶ȼ���
            that.resizeHeight();//�߶ȿ���
            that.renderCss();
        }
        //����༶��ͷ�������ͷ�߶�
        if(options.cols.length > 1){
            var th = that.layFixed.find(ELEM_HEADER).find('th');
            th.height(that.layHeader.height() - 1 - parseFloat(th.css('padding-top')) - parseFloat(th.css('padding-bottom')));
        }
        //��Ⱦ��������
        if(options.isFilter){
            that.layFilter.html(
                that.renderFilter()
            );
        }
        //��������
        that.pullData(that.page,that.loading());
        that.test();
    };
    //���������ͣ����ƻ�����
    Class.prototype.initOpts = function(item){
        var that = this,
            options = that.config;
        //�� type �������ݾɰ汾
        if(item.checkbox) item.type = "checkbox";
        if(item.space) item.type = "space";
        if(!item.type) item.type = "normal";

        if(item.type !== "normal"){
            item.unresize = true;
            item.width = item.width || table.config.initWidth[item.type];
        }

        if(options.isFilter){//�������ڹ���
            if(item.isFilter!=false){
                item.isFilter=true;
            }
        }
    };

    /**
     * �����ȡ�������߶�
     * @param tableId
     */
    Class.prototype.getParentDivHeight = function(tableId){
        var th=$("#"+tableId).parent().height();
        return th;
    };

    /**
     * ��ȡ�ж���
     * @param tableId
     */
    Class.prototype.getCols = function(field){
        var that = this;
        var o={};
        var cols=that.config.cols[0];
        var isInt=false;
        var reg = /^[0-9]+.?[0-9]*$/;
        if (reg.test(field)) {//����
            isInt=true;
        }
        for(var ii in cols){
            if(isInt){
                if(ii==parseInt(field)) return cols[ii];
            }else{
                if(field==cols[ii].field)return cols[ii];
            }
        }
        return o;
    };

    //��������
    Class.prototype.reload = function(options){
        var that = this;
        if(that.config.data && that.config.data.constructor === Array) delete that.config.data;
        that.config = $.extend({}, that.config, options);
        that.configFirst = $.extend({}, that.config, options);
        //��ȡ���ڹ��˵�ֵ
        that.render();
    };
    //ҳ��
    Class.prototype.page = 1;
    /**
     * �����±꣨����ɾ���Ȳ�����
     * 1��data-index�е��±�
     * 2��tr��data��ֵ
     * 3���±��ֶε�ֵ
     * @param list
     */
    Class.prototype.restNumbers=function(){
        var that = this
            ,options = that.config;
        var  trs=that.layBody.find('table tbody tr');
        var i=0;
        trs.each(function (o) {
            $(this).attr("data-index",i);
            $(this).find(".laytable-cell-numbers p").text(i+1);
            $(this).data('index',i);
            i++;
        });
    }

    /**
     * ��ʼ���ڵ�
     * ��ÿһ�����ݼ���ʱִֻ��һ��
     * query��reloadʱ��ִ��
     * @param o
     */
    Class.prototype.resetData=function(n) {
        var that = this
            ,options = that.config;
        if(options.isTree){
            if(!n.hasOwnProperty(table.config.cols.isOpen)){//��������ڸ�������Ĭ��Ϊtrue
                n[table.config.cols.isOpen]=options.isOpenDefault;
            }
            if(!n.hasOwnProperty(table.config.cols.isShow)){//��������ڸ�������Ĭ��Ϊtrue
                n[table.config.cols.isShow]=options.isOpenDefault?true:false;
            }
        }
        //��ֹ����
        if(!n.hasOwnProperty(table.config.cols.cheDisabled)){//��������Ĭ��Ϊfalse
            n[table.config.cols.cheDisabled]=false;
        }
        //��¼��ֹ��ѡ����ѡ�ļ�¼��
        if(n[table.config.cols.cheDisabled])options.cheDisabledNum++;
        if(n[table.config.cols.radDisabled])options.radDisabledNum++;
        n.children=[];
    }
    /**
     * ����map����
     * @param list
     * @return {{}}
     */
    Class.prototype.resetDataMap=function(list) {
        var that = this
            ,options = that.config;
        var field_Id=options.idField;
        var map={};
        if(list){
            list.forEach(function (o) {
                map[o[field_Id]]=o;
            });
        }
        return map;
    }
    Class.prototype.resetDataresetRoot=true;//�Ƿ�����ȷ�����ڵ�
    /**
     * ȷ�����ڵ�id(���µ�¼���ڵ�)
     */
    Class.prototype.resetDataRoot=function (list) {
        var that = this
            ,options = that.config;
        var field_Id=options[TREE_ID];
        var field_upId=options[TREE_UPID];
        var map=table.getDataMap(that.config.id);//�б�map��fieldIdΪkey  //����map���ݼ���
        var rootList=table.cache[options.id].data.upIds||[];//���ڵ�list����
        var rootMap={};//���ڵ�map����
        table.cache[options.id].data.upIds=[];
        rootList=table.cache[options.id].data.upIds;
        for(var i=0;i<list.length;i++){
            var temo=list[i];
            if(!map[temo[field_upId]]){//û���ҵ����ڵ�
                if(!rootMap[temo[field_upId]]){//��������
                    var temis=true;
                    rootList.forEach(function (temoo) {
                        if(temoo===temo[field_upId])temis=false;
                    });
                    if(temis)rootList.push(temo[field_upId]);
                }
                rootMap[temo[field_upId]]=temo[field_upId];
            }
        }
        return rootList;
    }
    /**
     * �������ṹ
     * 1��ԭʼ�б�����
     * 2�����ڵ㼯��
     */
    Class.prototype.resetDataTreeList=function (list, rootList) {
        var that = this
            ,options = that.config;
        var field_Id=options[TREE_ID];
        var field_upId=options[TREE_UPID];
        var treeList=[];
        //�������ṹ
        var fa = function(upId) {
            var _array = [];
            for (var i = 0; i < list.length; i++) {
                var n = list[i];
                if (n[field_upId] === upId) {
                    n.children = fa(n[field_Id]);
                    _array.push(n);
                }
            }
            return _array;
        }
        rootList.forEach(function (temo) {
            var temTreeObj=fa(temo);//�ݹ�
            if(temTreeObj){
                temTreeObj.forEach(function (o) {
                    treeList.push(o);
                });
            }
        });
        return treeList;
    }

    /**
     * ���������б��ṹ
     * 1�����ṹ
     */
    Class.prototype.resetDataTableList=function (treeList) {
        var that = this
            ,options = that.config;
        var field_Id=options[TREE_ID];
        var field_upId=options[TREE_UPID];
        var tableList=[];
        //��������ṹ
        var fa2=function (l,level) {
            for (var i = 0; i < l.length; i++) {
                var n = l[i];
                n[table.config.cols.level]=level;//���õ�ǰ�㼶
                tableList.push(n);
                if (n.children&&n.children.length>0) {
                    fa2(n.children,1+level);
                }
            }
            return;
        }
        fa2(treeList,1);

        //����isOpen ��is_show״̬
        tableList.forEach(function (o) {
            var uo=that.treeFindUpData(o);
            if(!uo||(uo[table.config.cols.isOpen]&&uo[table.config.cols.isShow])){//û�и��ף���ʾ�����״�״̬����ʾ״̬����ʾ������״̬�����أ�
                o[table.config.cols.isShow]=true;
            }else{
                o[table.config.cols.isShow]=false;
            }
        });
        return tableList;
    }

    /**
     * ���õ�ǰ��������ݣ�1����ͨ�б���2��״����
     * ���б�����ת�����νṹ�ͷ���tableչʾ���б�
     * @param list          �б�����
     * @param field_Id      ���νṹ�����ֶ�
     * @param field_upId    ���νṹ�ϼ��ֶ�
     * @returns {Array}     [0]�����б�  [1]���νṹ
     */
    Class.prototype.resetDatas=function(list) {
        //console.time("resetDatas");
        var that = this
            ,options = that.config;
        var field_Id=options[TREE_ID];
        var field_upId=options[TREE_UPID];
        var datas=[];
        var treeList=[];
        var tableList=list;
        var map=that.resetDataMap(list);//�б�map��fieldIdΪkey  //����map���ݼ���
        datas.push(tableList);//table�ṹ
        datas.push(treeList)//tree���ṹ
        datas.push(map)//data���� map�ṹ
        //���õ��ڴ���ȥ
        table.setDataList(that.config.id,tableList);
        table.setDataTreeList(that.config.id,treeList);
        table.setDataMap(that.config.id,map);
        if(list==null||list.length<=0)return datas;
        //����Ĭ�ϲ���
        for (var i = 0; i < list.length; i++) {
            that.resetData(list[i]);
        }
        if(options.isTree){//��״
            tableList=[];
            table.setDataList(that.config.id,tableList);
            var rootList=table.cache[options.id].data.upIds||[];//���ڵ�list����
            if(rootList.length<=0||that.resetDataresetRoot){//ȷ�����ڵ�
                table.cache[options.id].data.upIds=[];
                rootList=that.resetDataRoot(list);
                that.resetDataresetRoot=false;
            }
            treeList=that.resetDataTreeList(list,rootList);
            table.setDataTreeList(that.config.id,treeList);//�������ṹ������
            tableList=that.resetDataTableList(treeList);
            table.setDataList(that.config.id,tableList);//���������б��ṹ������
        }
        //console.timeEnd("resetDatas");
        return datas;
    }
    /**
     * ����id�ӱ��������л�ȡ����
     * @param data
     * @param field_Id
     * @param field_upId
     * @returns {Array}
     */
    Class.prototype.treeFindDataById=function(u_Id) {
        var that = this
            ,options = that.config;
        var e=null;
        var list=table.getDataList(that.key);
        var key=options[TREE_ID];
        list.forEach(function (o) {
            if(o[key]==u_Id){
                e=o;
                return;
            }
        });
        return e;
    }
    /**
     * ��ȡ���ڵ�
     * @param u_Id
     */
    Class.prototype.treeFindUpData=function(o){
        var uOjb=null;
        var that = this
            ,options = that.config;
        //��������
        var key=options[TREE_UPID];//���ڵ�key����
        var mapData=table.getDataMap(that.config.id);//��ȡmap��ʽ���󼯺�
        uOjb=mapData[o[key]];
        return uOjb;
    }
    /**
     * ��ȡȫ�����ڵ㼯�ϣ�����list(�������Լ�)
     * @param u_Id
     */
    Class.prototype.treeFindUpDatas=function(o){
        var uOjb=null;
        var that = this
            ,options = that.config;
        var list=[];
        var temf=function (temo) {
            var uo=that.treeFindUpData(temo);
            if(uo){
                list.push(uo);
                temf(uo);
            }
        };
        temf(o);
        return list;
    }
    /**
     * ���ݸ�id��ȡȫ����Ҷ�ӽڵ�(�ݹ�)
     * @param o ���ݶ���
     * @return {string}
     */
    Class.prototype.treeFindSonData=function (data) {
        var objs=[];
        function f(o) {
            if(o.children.length>0){
                o.children.forEach(function (i) {
                    objs.push(i);
                    if(i.children.length>0){
                        f(i);
                    }
                });
            }
        }f(data);
        return objs;
    };
    /**
     * Ҷ�ӽڵ���ʾת��
     * @param o             ����
     * @param fieldName     ����ʾ����
     * @returns {string}
     */
    Class.prototype.treeConvertShowName=function (o) {
        var that = this
            ,options = that.config;
        var isTreeNode=(o.children&&o.children.length>0);
        var temhtml='<div style="float: left;height: 28px;line-height: 28px;padding-left: '+
            function () {
                if(isTreeNode){
                    return '5px'
                }else{
                    return '21px'
                }
            }()
            +'">'
            +function () {//λ����
                var nbspHtml="<i>"//һ��λ��
                for(var i=1;i<o[table.config.cols.level];i++) {
                    nbspHtml = nbspHtml + "&nbsp;&nbsp;&nbsp;&nbsp;";
                }
                nbspHtml=nbspHtml+"</i>";
                return nbspHtml;
            }()
            +function () {//ͼ���ռλ��
                var temTreeHtml='';
                var temTreeIsOpen=o[table.config.cols.isOpen]?"&#xe625;":"&#xe623;";
                if(isTreeNode){//���ڵ�
                    temTreeHtml='<i class="layui-icon layui-tree-head">'+temTreeIsOpen+'</i>'
                        +that.treeIconRender(o,true);
                }else{//Ҷ�ӽڵ�
                    temTreeHtml+=that.treeIconRender(o,true);
                }
                return temTreeHtml;
            }()
            +'</div>';
        return temhtml;
    };
    /**
     * �ڵ��չ�����۵�
     * @param o         �ڵ����ݣ���״����
     * @param isOpen    չ����true�����۵���false��
     *
     * ÿ���ڵ�������״̬��
     * 1����״̬��isOpen��   ��״ֻ̬���ڵ��˲����ƣ�����ʱ����Ҫ�䶯
     * 2����ʾ״̬����ʾ�����أ� ��ʾ״̬���ݸ����ڵ���ƣ������ڵ�����ʾ���Ҵ�״̬������ʾ��������ʾ������Ӱ�����״̬
     */
    Class.prototype.treeNodeOpen=function (o,isOpen) {
        var that = this
            ,tr = that.layBody.find('tr[data-index="'+ o[table.config.indexName] +'"]');
        if(!o){
            return
        }
        o[table.config.cols.isOpen]=isOpen;
        //�������ṹ
        var fa = function(e) {
            if(e.children&&e.children.length>0){
                var temList=e.children;
                for (var i = 0; i < temList.length; i++) {
                    var n = temList[i];
                    if(o[table.config.cols.isOpen]){//��״̬�ģ��ر�
                        if(e[table.config.cols.isOpen]&&e[table.config.cols.isShow]){//�ýڵ���ʾ
                            var temo=that.layBody.find('tr[data-index="'+ n[table.config.indexName] +'"]');
                            temo.css('display', '');
                            n[table.config.cols.isShow]=true;
                        }
                    }else{
                        var temo=that.layBody.find('tr[data-index="'+ n[table.config.indexName] +'"]');
                        temo.css('display', 'none');
                        n[table.config.cols.isShow]=false;
                    }
                    fa(n);
                }
            }
        }
        fa(o);
        //����ͼ��
        that.treeIconRender(o,false);
        var dbClickI=tr.find('.layui-tree-head');
        if(o[table.config.cols.isOpen]){//��״̬
            dbClickI.html('&#xe625;');
        }else{
            dbClickI.html('&#xe623;');
        }
    };

    /**
     * icon��Ⱦ
     * @param o
     * @param isHtml  true������html��  false��������Ⱦ��
     */
    Class.prototype.treeIconRender=function (o,isHtml) {
        var that = this
            ,options = that.config
            ,iconOpen=options.iconOpen
            ,isTreeNode=(o.children&&o.children.length>0);
        var temTreeHtml='';
        if(iconOpen){
            var temf=function () {//�Զ���ͼ��
                var temhtml='<i class="layui-tree-'+o[options.idField]+'" style="display:inline-block;width: 16px;height: 16px;background:url(';
                if(isTreeNode){//���ڵ�
                    if(o[table.config.cols.isOpen]){
                        temhtml+=o[table.config.cols.iconOpen];
                    }else{
                        temhtml+=o[table.config.cols.iconClose];
                    }
                }else{
                    temhtml+=o[table.config.cols.icon];
                }
                temhtml+=') 0 0 no-repeat;"></i>';
                return temhtml;
            }
            if(isTreeNode){//���ڵ�
                if((o[table.config.cols.iconOpen]||o[table.config.cols.iconClose])){
                    temTreeHtml=temf();
                }else{
                    temTreeHtml='<i class="layui-icon layui-tree-'+o[options.idField]+' layui-tree-'+ (o[table.config.cols.isOpen] ? "branch" : "leaf") +'" '+iconOpen+'>'+(o[table.config.cols.isOpen]?that.config.branch[1]:that.config.branch[0])+'</i>';
                }
            }else{//Ҷ�ӽڵ�
                if(o[table.config.cols.icon]){
                    temTreeHtml=temf();
                }else{
                    temTreeHtml+='<i class="layui-icon layui-tree-'+o[options.idField]+' layui-tree-leaf"  '+iconOpen+'>'+that.config.leaf+'</i>';
                }
            }
            if(isHtml){
                return temTreeHtml;
            }else{
                var temdiv=that.layBody.find('tr[data-index="'+ o[table.config.indexName] +'"]').find('td[data-field='+options[TREE_SHOW_NAME]+']').find('.layui-table-cell');
                $(temdiv).find('div .layui-tree-'+o[options.idField]).remove();//�ڵ㸽��div
                $(temdiv).find('div').append(temTreeHtml);
            }
        }else{
            return temTreeHtml;
        }
    }
    //�������
    Class.prototype.pullData = function(curr, loadIndex){
        var that = this
            ,options = that.config
            ,request = options.request
            ,response = options.response
            ,sort = function(){
                if(typeof options.initSort === 'object'){
                    that.sort(options.initSort.field, options.initSort.type);
                }
            };
        that.startTime = new Date().getTime(); //��Ⱦ��ʼʱ��
        if(options.url){ //Ajax����
            var params = {};
            params[request.pageName] = curr;
            params[request.limitName] = options.limit;
            that.filterRulesSet(params);//���ڹ�������
            that.sortSet(params);//��������
            $.ajax({
                type: options.method || 'get'
                ,url: options.url
                ,data: $.extend(params, options.where)
                ,dataType: 'json'
                ,success: function(res){
                    if(!res[response.dataName]){//������δ�����nullʱת��[]
                        res[response.dataName]=[]
                        res[response.statusName]=0;
                        res[response.countName]=0;
                        res[response.msgName]='���ص�����״̬�쳣';
                    };
                    that.resetDataresetRoot=true;
                    //��������ݽ����Ļص��������䷵�ص�����
                    if(typeof options.parseData === 'function'){
                        res = options.parseData(res) || res;
                    }
                    that.resetDatas(res[response.dataName]);
                    res[response.dataName]=table.getDataList(options.id);
                    if(res[response.statusName] != response.statusCode){
                        that.renderForm();
                        that.layMain.html('<div class="'+ NONE +'">'+ (res[response.msgName] || '���ص�����״̬�쳣') +'</div>');
                    } else {
                        that.renderData(res, curr, res[response.countName]);
                        options.time = (new Date().getTime() - that.startTime) + ' ms'; //��ʱ���ӿ�����+��ͼ��Ⱦ��
                    }
                    loadIndex && layer.close(loadIndex);
                    that.events();
                    typeof options.done === 'function' && options.done(res, curr, res[response.countName]);
                }
                ,error: function(e, m){
                    that.layMain.html('<div class="'+ NONE +'">���ݽӿ������쳣</div>');
                    that.renderForm();
                    loadIndex && layer.close(loadIndex);
                }
            });
        } else if(options.data && options.data.constructor === Array){ //��֪����
            var res = {},startLimit = curr*options.limit - options.limit
            res[response.dataName] = options.data.concat().splice(startLimit, options.limit);
            res[response.countName] = options.data.length;
            that.renderData(res, curr, options.data.length);
            that.events();
            typeof options.done === 'function' && options.done(res, curr, res[response.countName]);
        }
    };
    /**
     * ���ù�������
     */
    Class.prototype.filterRulesSet=function (p) {
        var that = this;
        p["filterRules"]=JSON.stringify(that.filterRules());
    }
    /**
     * ��ȡ��������
     * filterRules:
     * [
     * {"field":"XXXX","op":"equals","value":["1"],"datatype":"array"}
     * ,{"field":"XXXX","op":"contains","value":"3","datatype":"string"}
     * ]
     */
    Class.prototype.filterRules=function () {
        var that = this;
        var filterRules=[];
        //���ڹ�������
        var list=that.layFilter.find("[name^='filter_']");
        layui.each(list,function (i, o) {
            if($(o).val()){
                var tem={
                    "field":o.name
                    ,"op":"like"
                    ,"value":$(o).val()
                    ,"datatype":"string"
                }
                filterRules.push(tem);
            }
        });
        // console.log(filterRules,filterRules.toString(),JSON.stringify(filterRules));
        return filterRules;
    }

    //������ͷ
    Class.prototype.eachCols = function(callback){
        var cols = $.extend(true, [], this.config.cols)
            ,arrs = [], index = 0;

        //����������ͷ�ṹ
        layui.each(cols, function(i1, item1){
            layui.each(item1, function(i2, item2){
                //���������У��򲶻��Ӧ������
                if(item2.colspan > 1){
                    var childIndex = 0;
                    index++
                    item2.CHILD_COLS = [];
                    layui.each(cols[i1 + 1], function(i22, item22){
                        if(item22.PARENT_COL || childIndex == item2.colspan) return;
                        item22.PARENT_COL = index;
                        item2.CHILD_COLS.push(item22);
                        childIndex = childIndex + (item22.colspan > 1 ? item22.colspan : 1);
                    });
                }
                if(item2.PARENT_COL) return; //��������У��򲻽���׷�ӣ���Ϊ�Ѿ��洢�ڸ�����
                arrs.push(item2)
            });
        });

        //���±����У���������У������ݹ�
        var eachArrs = function(obj){
            layui.each(obj || arrs, function(i, item){
                if(item.CHILD_COLS) return eachArrs(item.CHILD_COLS);
                callback(i, item);
            });
        };

        eachArrs();
    };
    /**
     * ��Ⱦ�ڵ���ʾ
     * @param callback
     */
    Class.prototype.renderTreeConvertShowName = function(o){
        var that = this
            ,options = that.config
            ,m=options.elem
            ,hasRender = m.next('.' + ELEM_VIEW);
        var temhtml=that.treeConvertShowName(o);
        var temdiv=that.layBody.find('tr[data-index="'+ o[table.config.indexName] +'"]').find('td[data-field='+options[TREE_SHOW_NAME]+']').find('.layui-table-cell');
        $(temdiv).find('div').remove();
        $(temdiv).prepend(temhtml);
    }
    /**
     * ��Ⱦ����Ԫ����ʽ(������ʽ����)
     * @param callback
     */
    Class.prototype.renderTdCss = function(){
        var that = this
            ,options = that.config
            ,m=options.elem
            ,hasRender = m.next('.' + ELEM_VIEW);
        var id= that.index+"_"+MOD_NAME+'_td_style';
        hasRender.find("#"+id).remove();
        var styel='<style id="'+id+'">'
            +function () {
                var ret="";
                layui.each(that.config.cols,function (i1, item1) {
                    layui.each(item1, function(i2, item2){
                        ret+='.laytable-cell-'+that.index+'-'+(item2.field||i2)+'{' +
                            'width:'+(item2.width?item2.width+"px":"0px")
                            +'}';
                    });
                });
                return ret;
            }()+'</style>';
        hasRender.append(styel);
    }

    /**
     * �����css
     */
    Class.prototype.renderCss = function(){
        var that = this
            ,options = that.config
            ,m=options.elem
            ,hasRender = m.next('.' + ELEM_VIEW);
        var id=that.index+"_"+MOD_NAME+'_style';
        hasRender.find("#"+id).remove();
        var styel='<style id="'+id+'">'
            +function () {
                var ret=".layui-tree-head{cursor: pointer;}";//��ͼ������ʽ
                ret+=".layui-table-view {margin:0;}";
                return ret;
            }()+'</style>';
        hasRender.append(styel);
    }

    /**
     * ���ɵ�Ԫ��
     * @param obj       ������
     * @param numbers   �±�
     * @param cols      �ж�������
     * @param i3        �ڼ���
     */
    Class.prototype.renderTrUpids=function (obj) {
        var that = this
            ,options = that.config;
        var tree_upid_key=options[TREE_UPID];
        var upids=' upids="'+obj["upIds"]+'" ';
        var u_id=' u_id="'+obj[tree_upid_key]+'" '
        var ret=options.isTree?u_id:'';
        return ret;
    }
    /**
     * ���ɵ�Ԫ��
     * @param obj       ������
     * @param numbers   �±�
     * @param cols      �ж�������
     * @param i3        �ڼ���
     */
    Class.prototype.renderTd=function (obj,cols,numbers,i3) {
        var that = this
            ,options = that.config;
        var v=obj[cols.field]==null?'':String(obj[cols.field]);

        var field = cols.field || i3, content = v
            ,cell = that.getColElem(that.layHeader, field);

        var treeImgHtml='';
        if(options.isTree){
            if(options.treeShowName==cols.field){
                treeImgHtml=that.treeConvertShowName(obj);
            }
        }
        //td����
        var td = ['<td data-field="'+ field +'" '+ function(){
            var attr = [];
            if(cols.edit) attr.push('data-edit="'+ cols.edit +'"'); //�Ƿ�������Ԫ��༭
            if(cols.align) attr.push('align="'+ cols.align +'"'); //���뷽ʽ
            if(cols.templet) attr.push('data-content="'+ content +'"'); //�Զ���ģ��
            if(cols.toolbar) attr.push('data-off="true"'); //�Զ���ģ��
            if(cols.event) attr.push('lay-event="'+ cols.event +'"'); //�Զ����¼�
            if(cols.style) attr.push('style="'+ cols.style +'"'); //�Զ�����ʽ
            if(cols.minWidth) attr.push('data-minwidth="'+ cols.minWidth +'"'); //��Ԫ����С����
            return attr.join(' ');
        }() +'>'
            ,'<div class="layui-table-cell laytable-cell-'+ function(){ //���ض�Ӧ��CSS���ʶ
                var str = (options.index + '-' + field);
                return cols.type === 'normal' ? str
                    : (str + ' laytable-cell-' + cols.type);
            }() +'">'+treeImgHtml+'<p style="width: auto;height: 100%;">'+ function(){
                var tplData = $.extend(true, {LAY_INDEX: numbers}, obj);
                //��Ⱦ��ѡ������ͼ
                if(cols.type === 'checkbox'){
                    return tplData[table.config.cols.cheDisabled]?''
                        :'<input type="checkbox" name="'+TABLE_CHECKBOX_ID+'" value="'+tplData[table.config.indexName]+'" lay-skin="primary" '+ function(){
                        var isCheckName = table.config.cols.isCheckName;
                        //�����ȫѡ
                        if(cols[isCheckName]){
                            obj[isCheckName] = cols[isCheckName];
                            return cols[isCheckName] ? 'checked' : '';
                        }
                        return tplData[isCheckName] ? 'checked' : '';
                    }() +'>';
                } else if(cols.type === 'numbers'){ //��Ⱦ���
                    return numbers;
                }else if(cols.type === 'drop'){//������
                    var rowsField=dl.ui.table.drop.findFieldObj(options.cols[0],field);
                    if(rowsField&&rowsField['drop']){
                        var o=dl.cache.code.get(rowsField.drop);
                        return dl.ui.table.drop.findDropLable(rowsField.drop,content);
                    }
                }else if(cols.type === 'radio'){//��ѡ
                    return tplData[table.config.cols.radDisabled]?''
                        :'<input type="radio" name="'+TABLE_RADIO_ID+'" '+function () {
                        var isRadio = table.config.cols.isRadio;
                        if(cols[isRadio]){
                            obj[isRadio] = cols[isRadio];
                            return cols[isRadio] ? 'checked' : '';
                        }
                        return tplData[isRadio] ? 'checked' : '';
                    }()+' value="'+tplData[table.config.indexName]+'" title=" ">';
                }

                //����������ģ��
                if(cols.toolbar){
                    return laytpl($(cols.toolbar).html()||'').render(tplData);
                }

                return cols.templet ? function(){
                    return typeof cols.templet === 'function'
                        ? cols.templet(tplData)
                        : laytpl($(cols.templet).html() || String(content)).render(tplData)
                }() : content;
            }()
            ,'</p></div></td>'].join('');
        return td;
    }
    /**
     * ����tr�е�һ��
     * @param obj            ������
     * @param numbers          �к�
     */
    Class.prototype.renderTr=function (obj,numbers) {
        var that = this
            ,options = that.config;
        var tds= [];
        that.eachCols(function(i3, cols){//cols�ж���
            var field = cols.field || i3, content = obj[field];
            if(cols.colspan > 1) return;
            var td = that.renderTd(obj,cols,numbers,i3);//td����
            tds.push(td);
            // if(item3.fixed && item3.fixed !== 'right') tds_fixed.push(td);
            // if(item3.fixed === 'right') tds_fixed_r.push(td);
        });
        return tds;
    };
    /**
     * �������ݲ�����Ⱦ���
     * @param res
     * @param curr
     * @param count
     * @param sort
     */
    Class.prototype.renderData = function(res, curr, count, sort){
        var that = this
            ,options = that.config
            ,data = res[options.response.dataName] || []
            ,trs = []
            ,trs_fixed = []
            ,trs_fixed_r = []
            //��Ⱦ��ͼ
            ,render = function(){ //���������������ص�
                if(!sort && that.sortKey){
                    return that.sort(that.sortKey.field, that.sortKey.sort, true);
                }

                layui.each(data, function(i1, obj){
                    var uo=that.treeFindUpData(obj);
                    var display="";
                    if(!obj[table.config.cols.isShow]&&options.isTree){
                        display="display: none;";
                    }
                    var tds = [], tds_fixed = [], tds_fixed_r = []
                        ,numbers = i1 + options.limit*(curr - 1) + 1; //���
                    if(obj.length === 0) return;
                    if(!sort){
                        obj[table.config.indexName] = i1;
                    }
                    tds=that.renderTr(obj,numbers);
                    trs.push('<tr style="'+display+'" data-index="'+ i1 +'" '+that.renderTrUpids(obj)+'>'+ tds.join('') + '</tr>');
                    trs_fixed.push('<tr data-index="'+ i1 +'">'+ tds_fixed.join('') + '</tr>');
                    trs_fixed_r.push('<tr data-index="'+ i1 +'">'+ tds_fixed_r.join('') + '</tr>');
                });
                //if(data.length === 0) return;
                that.layBody.scrollTop(0);
                that.layMain.find('.'+ NONE).remove();
                that.layMain.find('tbody').html(trs.join(''));
                that.layFixLeft.find('tbody').html(trs_fixed.join(''));
                that.layFixRight.find('tbody').html(trs_fixed_r.join(''));
                that.renderForm();
                that.haveInit ? that.scrollPatch() : setTimeout(function(){
                    that.scrollPatch();
                }, 50);
                that.haveInit = true;
                layer.close(that.tipsIndex);
            };
        that.key = options.id || options.index;
        // table.cache[that.key] = data; //��¼����
        table.setDataList(that.key,data);
        //��ʾ���ط�ҳ��
        that.layPage[data.length === 0 && curr == 1 ? 'addClass' : 'removeClass'](HIDE);
        //����
        if(sort){
            return render();
        }
        if(data.length === 0){
            that.renderForm();
            that.layFixed.remove();
            that.layMain.find('tbody').html('');
            that.layMain.find('.'+ NONE).remove();
            return that.layMain.append('<div class="'+ NONE +'">'+(res[options.response.msgName]?res[options.response.msgName]:options.text.none)+'</div>');
        }
        render();
        that.renderPage(count);//��ҳ��Ⱦ
        //calss�������
        table.pushClassIds(options.id,true);
    };
    /**
     * ��Ⱦ��ҳ
     */
    Class.prototype.renderPage=function (count) {
        var that = this
            ,options = that.config;
        //ͬ����ҳ״̬
        if(options.isPage){
            options.page = $.extend({
                elem: 'layui-table-page' + options.index
                ,count: count
                ,limit: options.limit
                ,limits: options.limits || [10,15,20,30,40,50,60,70,80,90]
                ,groups: 3
                ,layout: ['prev', 'page', 'next', 'skip', 'count', 'limit']
                ,prev: '<i class="layui-icon">&#xe603;</i>'
                ,next: '<i class="layui-icon">&#xe602;</i>'
                ,jump: function(obj, first){
                    if(!first){
                        //��ҳ����������Ҫ�����¸��£����������ͬ������Ҫ����Ϊ��������ͳһ�õ�������
                        //�������õ��� options.page �еĲ�������ȷ����ҳδ�����������������ʹ�ã�
                        that.page = obj.curr; //����ҳ��
                        options.limit = obj.limit; //����ÿҳ����
                        that.pullData(obj.curr, that.loading());
                    }
                }
            }, options.page);
            options.page.count = count; //����������
            laypage.render(options.page);
        }
    };
    /**
     * �����������Ⱦ
     */
    Class.prototype.renderFilter = function(){
        var that = this
            ,options = that.config
            ,VIEW_CLASS=ELEM_VIEW
            ,index=that.index; //����
        var v = [];
        v.push('<form method="post"  id="'+options.id+'_filter_form">');
        v.push('<table cellspacing="0" cellpadding="0" border="0" class="layui-table"><thead><tr>');
        layui.each(options.cols,function (i, o) {
            layui.each(o, function(i2, item2){
                var field=item2.field||i2;
                var minW=item2.minWidth?"data-minwidth='"+item2.minWidth+"'":"";
                var rowCols=item2.colspan?'colspan="'+item2.colspan+'"':'';
                var rowspan=item2.rowspan?'rowspan="'+item2.rowspan+'"':'';
                var unresize=item2.unresize?'data-unresize="true"':'';
                v.push('<th data-field="'+field+'"'+minW+rowCols+rowspan +unresize+'>');
                v.push('<div class="layui-table-cell laytable-cell-'+function () {
                    var tem="";
                    if (item2.colspan > 1) {
                        tem='group';
                    }else{
                        tem=index+"-"+field;
                        if(item2.type !== "normal"){
                            tem+=" laytable-cell-"+item2.type;
                        }
                    }
                    return tem;
                }()+'">');
                if(!item2.isFilter||!item2.field){//���������ڹ��˻�û������
                    v.push('');
                }else{
                    v.push('<input class="layui-input '+ ELEM_EDIT +'" id="filter_'+item2.field+'" name="filter_'+item2.field+'">');
                }
                v.push('</div></th>');

            });
        });
        v.push('</tr></thead></table>');
        v.push('</form>');
        return v.join('');
    };
    //�ҵ���Ӧ����Ԫ��
    Class.prototype.getColElem = function(parent, field){
        var that = this
            ,options = that.config;
        return parent.eq(0).find('.laytable-cell-'+ (options.index + '-' + field) + ':eq(0)');
    };
    //��Ⱦ����
    Class.prototype.renderForm = function(type){
        form.render(type, 'LAY-table-'+ this.index);
    }
    /**
     * �����������
     * @param p
     */
    Class.prototype.sortSet=function (p) {
        var that = this;
        var sort=[];
        var cols=that.config.cols[0];
        cols.forEach(function (t) {
            if(t.sortType){
                var tem={
                   "field":t.field
                    ,"sort":t.sortType
                }
                sort.push(tem);
            }
        });
        p.sort=JSON.stringify(sort);
    }
    /**
     * ���������ֶ�
     * @param th
     * @param type
     * @param pull
     * @param formEvent
     */
    Class.prototype.sort = function(th, type, pull, formEvent){
        var that = this
            ,field
            ,res = {}
            ,options = that.config
            ,filter = options.elem.attr('lay-filter')
            ,data = table.getDataList(that.key), thisData;
        //�ֶ�ƥ��
        if(typeof th === 'string'){
            that.layHeader.find('th').each(function(i, item){
                var othis = $(this)
                    ,_field = othis.data('field');
                if(_field === th){
                    th = othis;
                    field = _field;
                    return false;
                }
            });
        }
        try {
            var field = field || th.data('field');
            //�����ִ�е���������״̬�У���ִ����Ⱦ
            if(that.sortKey && !pull){
                if(field === that.sortKey.field && type === that.sortKey.sort){
                    return;
                }
            }
            var elemSort = that.layHeader.find('th .laytable-cell-'+ options.index +'-'+ field).find(ELEM_SORT);
            //that.layHeader.find('th').find(ELEM_SORT).removeAttr('lay-sort'); //���������������״̬
            elemSort.attr('lay-sort', type || null);
            that.layFixed.find('th')
        } catch(e){
            return hint.error('Table modules: Did not match to field');
        }
       /* //��¼��������������
        that.sortKey = {
            field: field
            ,sort: type
        };
        if(type === 'asc'){ //����
        } else if(type === 'desc'){ //����
            thisData = layui.sort(data, field, true);
        } else { //�������
            thisData = layui.sort(data, table.config.indexName);
        }
        */
        var cols=that.getCols(field);
        if(cols){
            cols.sortType=type
        }
    };
    //����loading
    Class.prototype.loading = function(){
        var that = this
            ,options = that.config;
        if(options.loading && options.url){
            return layer.msg('����������', {
                icon: 16
                ,offset: [
                    that.elem.offset().top + that.elem.height()/2 - 35 - _WIN.scrollTop() + 'px'
                    ,that.elem.offset().left + that.elem.width()/2 - 90 - _WIN.scrollLeft() + 'px'
                ]
                ,time: -1
                ,anim: -1
                ,fixed: false
            });
        }
    };
    //ͬ��ѡ��ֵ״̬
    Class.prototype.setCheckData = function(index, checked){
        var that = this
            ,options = that.config
            ,thisData = table.getDataList(that.key);
        if(!thisData[index]) return;
        if(thisData[index].constructor === Array) return;
        thisData[index][table.config.cols.isCheckName] = checked;
    };
    //ͬ��ȫѡ��ť״̬
    Class.prototype.syncCheckAll = function(){
            var that = this
                ,options = that.config;
            var list=table.getDataList(that.config.id);
            if(!list)return;
            var temis=true;//ȫѡ
            var checkNum=0;//ѡ�еĸ���
            list.forEach(function (t) {
                if(!t[table.config.cols.cheDisabled]){
                    if(t[table.config.cols.isCheckName]){
                        var  checkAllElem = that.layBody.find('tr[data-index='+t[table.config.indexName]+']').find('input[name="'+TABLE_CHECKBOX_ID+'"]');
                        checkAllElem.prop('checked', true);
                        checkNum++;
                    }else{
                        temis=false;
                        var  checkAllElem = that.layBody.find('tr[data-index='+t[table.config.indexName]+']').find('input[name="'+TABLE_CHECKBOX_ID+'"]');
                        checkAllElem.prop('checked', false);
                    }
                }
            });
            if(temis){//����ȫѡ
                var  checkAllElem = that.layHeader.find('input[name="'+TABLE_CHECKBOX_ID+'"]');
                checkAllElem.prop('checked', true);
            }
            if(checkNum<(list.length-options.cheDisabledNum)){
                var  checkAllElem = that.layHeader.find('input[name="'+TABLE_CHECKBOX_ID+'"]');
                checkAllElem.prop('checked', false);
            }
        // console.time("pullData");
        // console.timeEnd("pullData");
        that.renderForm('checkbox');
    };
    //��ȡcssRule
    Class.prototype.getCssRule = function(field, callback){
        var that = this
            ,style = that.elem.find('style')[0]
            ,sheet = style.sheet || style.styleSheet || {}
            ,rules = sheet.cssRules || sheet.rules;
        layui.each(rules, function(i, item){
            if(item.selectorText === ('.laytable-cell-'+ that.index +'-'+ field)){
                return callback(item), true;
            }
        });
    };

    Class.prototype.test = function(){
    }
    /**
     * ����仯����Ӧ
     */
    Class.prototype.resize = function(){
        var that = this;
        //���ݸ�����߶�����table�ĸ߶�
        // 1��table�������������߶ȣ�layui-table-view��
        // 2����������߶ȣ�layui-table-main��
        that.columnWidthInit();//�п��ȼ���
        that.tableHeight();//����߶ȼ���
        that.resizeHeight();//�߶ȿ���
        that.resizeWidth();//���ȿ���
    };

    //��̬�����п���
    Class.prototype.setArea = function(){
        var that = this;
        that.columnWidthInit();//�п��ȼ���
        that.tableHeight();//����߶ȼ���
    };
    /**
     * �п��ȼ���
     */
    Class.prototype.columnWidthInit = function(){
        var that = this,
            options = that.config
            ,colNums = 0 //�и���
            ,autoColNums = 0 //�Զ��п����и���
            ,autoWidth = 0 //�Զ��з���Ŀ���
            ,countWidth = 0 //�������ܿ��Ⱥ�
            ,cntrWidth = options.width ||function(){ //��ȡ��������
                //�����Ԫ�ؿ���Ϊ0��һ��Ϊ����Ԫ�أ�������������ϲ�Ԫ�أ�ֱ���ҵ���ʵ����Ϊֹ
                var getWidth = function(parent){
                    var width, isNone;
                    parent = parent || options.elem.parent()
                    width = parent.width();
                    try {
                        isNone = parent.css('display') === 'none';
                    } catch(e){}
                    if(parent[0] && (!width || isNone)) return getWidth(parent.parent());
                    return width;
                };
                return getWidth();
            }()-17;
        //ͳ���и���
        that.eachCols(function(){
            colNums++;
        });
        //��ȥ�߿��
        cntrWidth = cntrWidth - function(){
            return (options.skin === 'line' || options.skin === 'nob') ? 2 : colNums + 1;
        }();

        //����������
        layui.each(options.cols, function(i1, item1){
            layui.each(item1, function(i2, item2){
                var width;
                if(!item2){
                    item1.splice(i2, 1);
                    return;
                }
                that.initOpts(item2);
                width = item2.width || 0;
                if(item2.colspan > 1) return;
                if(/\d+%$/.test(width)){
                    item2.width = width = Math.floor((parseFloat(width) / 100) * cntrWidth);
                } else if(item2._is_width_dev||!width){ //�п�δ��д
                    item2._is_width_dev=true;//����Ĭ�Ͽ��ȵ���
                    item2.width = width = 0;
                    autoColNums++;
                }
                countWidth = countWidth + width;
            });
        });
        that.autoColNums = autoColNums; //��¼�Զ�����
        //���δ���������ʣ�����ƽ�֡����򣬸�δ�趨���ȵ��и�ֵһ��Ĭ�Ͽ�
        (cntrWidth > countWidth && autoColNums) && (
            autoWidth = (cntrWidth - countWidth) / autoColNums
        );
        layui.each(options.cols, function(i1, item1){
            layui.each(item1, function(i2, item2){
                var minWidth = item2.minWidth || options.cellMinWidth;
                if(item2.colspan > 1) return;
                if(item2.width === 0){
                    item2.width = Math.floor(autoWidth >= minWidth ? autoWidth : minWidth); //���ܵ����趨����С����
                }
            });
        });
    };
    /**
     * ������Ⱦ����
     */
    Class.prototype.resizeWidth = function(){
        var that = this;
        that.renderTdCss();
    };
    /**
     * ����߶ȼ���
     */
    Class.prototype.tableHeight = function(){
        var that = this,
            options = that.config,
            optionsFirst = that.configFirst;
        //ȷ���߶�
        if(!table.kit.isNumber(optionsFirst.height)){//����ǹ̶��߶ȣ������߶�
            var htremove=0;//��ȥ�ĸ߶�
            if(options.heightRemove&&table.kit.isArray(options.heightRemove)){
                var htatt=options.heightRemove;
                htatt.forEach(function (t) {
                    var temh=table.kit.isNumber(t)?t:$(t).outerHeight(true);
                    if(table.kit.isNumber(temh)){
                        htremove+=temh;
                    }
                });
            }
            //�߶�������full-���ֵ
            var th=_WIN.height()-htremove-1;//that.getParentDivHeight(options.id);
            that.fullHeightGap=0;
            if(options.height){
                if(/^full-\d+$/.test(options.height)){
                    that.fullHeightGap = options.height.split('-')[1];
                }
            }
            options.height = th - that.fullHeightGap;
        }
    };
    /**
     * ������Ⱦ�߶�
     */
    Class.prototype.resizeHeight = function(){
        var that = this
            ,options = that.config
            ,height = options.height, bodyHeight;
        if(height < 135) height = 135;
        that.elem.css('height', height);
        //tbody����߶�
        // bodyHeight = parseFloat(height) - parseFloat(that.layHeader.height()) - 1;//ԭ������
        var theader=options.isFilter?76:38;//û�����ڹ�������
        bodyHeight = parseFloat(height) - theader - 1;//###ע�⣺����д����ͷ�̶��߶�Ϊ38px������֧�ֶ��ͷ��ʽ����tab��ʽ���޷���ȡ��ȷ�ĸ߶ȣ���������
        if(options.toolbar){
            bodyHeight = bodyHeight - that.layTool.outerHeight();
        }
        if(options.isPage){
            bodyHeight = bodyHeight - that.layPage.outerHeight() - 1;
        }
        that.layMain.css('height', bodyHeight);
    };
    //��ȡ����������
    Class.prototype.getScrollWidth = function(elem){
        var width = 0;
        if(elem){
            width = elem.offsetWidth - elem.clientWidth;
        } else {
            elem = document.createElement('div');
            elem.style.width = '100px';
            elem.style.height = '100px';
            elem.style.overflowY = 'scroll';

            document.body.appendChild(elem);
            width = elem.offsetWidth - elem.clientWidth;
            document.body.removeChild(elem);
        }
        return width;
    };
    //����������
    Class.prototype.scrollPatch = function(){
        var that = this
            ,layMainTable = that.layMain.children('table')
            ,scollWidth = that.layMain.width() - that.layMain.prop('clientWidth') //�������������
            ,scollHeight = that.layMain.height() - that.layMain.prop('clientHeight') //����������߶�
            ,getScrollWidth = that.getScrollWidth(that.layMain[0]) //��ȡ���������������ȣ�����еĻ�
            ,outWidth = layMainTable.outerWidth() - that.layMain.width(); //�����������ĳ�������

        //��������Զ��п�����Ҫ��֤��������������Ҳ��ܳ��ֺ��������
        if(that.autoColNums && outWidth < 5 && !that.scrollPatchWStatus){
            var th = that.layHeader.eq(0).find('thead th:last-child')
                ,field = th.data('field');
            that.getCssRule(field, function(item){
                var width = item.style.width || th.outerWidth();
                item.style.width = (parseFloat(width) - getScrollWidth - outWidth) + 'px';
                //����У�飬�����Ȼ���ֺ��������
                if(that.layMain.height() - that.layMain.prop('clientHeight') > 0){
                    item.style.width = parseFloat(item.style.width) - 1 + 'px';
                }
                that.scrollPatchWStatus = true;
            });
        }
        if(scollWidth && scollHeight){
            if(that.elem.find('.layui-table-patch').length<=0){
                var patchElem = $('<th class="layui-table-patch"><div class="layui-table-cell"></div></th>'); //����Ԫ��
                patchElem.find('div').css({
                    width: scollWidth
                });
                that.layHeader.eq(0).find('thead tr').append(patchElem);
                //that.layFilter.find('table thead tr').append(patchElem);
            }
        } else {
            that.layFilter.eq(0).find('.layui-table-patch').remove();
            that.layHeader.eq(0).find('.layui-table-patch').remove();
        }
        //�̶�������߶�
        var mainHeight = that.layMain.height()
            ,fixHeight = mainHeight - scollHeight;
        that.layFixed.find(ELEM_BODY).css('height', layMainTable.height() > fixHeight ? fixHeight : 'auto');
        //�������С����������ʱ�����ع̶���
        that.layFixRight[outWidth > 0 ? 'removeClass' : 'addClass'](HIDE);
        //������
        that.layFixRight.css('right', scollWidth - 1);
    };
    //�¼�����
    Class.prototype.events = function(){
        var that = this
            ,options = that.config
            ,_BODY = $('body')
            ,dict = {}
            ,th = that.layHeader.find('th')
            ,bodytr=that.layBody.find('tr')
            ,resizing;
        //�е���¼�
        bodytr.unbind('click').on('click',function (e) {
            var index=$(this).attr("data-index");
            var list=table.getDataList(that.config.id);
            var o=list[index];
            typeof options.onClickRow === 'function' && options.onClickRow(index,o);
        });
        //��˫���¼�
        bodytr.unbind('dblclick').on('dblclick',function (e) {
            var index=$(this).attr("data-index");
            var list=table.getDataList(that.config.id);
            var o=list[index];
            typeof options.onDblClickRow === 'function' && options.onDblClickRow(index,o);
        });
        //��ק��������
        th.unbind('mousemove').on('mousemove', function(e){
            var othis = $(this)
                ,oLeft = othis.offset().left
                ,pLeft = e.clientX - oLeft;
            if(othis.attr('colspan') > 1 || othis.data('unresize') || dict.resizeStart){
                return;
            }
            dict.allowResize = othis.width() - pLeft <= 10; //�Ƿ�����ק��������
            _BODY.css('cursor', (dict.allowResize ? 'col-resize' : ''));
        })
        th.unbind('mouseleave').on('mouseleave', function(){
            var othis = $(this);
            if(dict.resizeStart) return;
            _BODY.css('cursor', '');
        })
        th.unbind('mousedown').on('mousedown', function(e){
            var othis = $(this);
            if(dict.allowResize){
                var field = othis.data('field');
                e.preventDefault();
                dict.resizeStart = true; //��ʼ��ק
                dict.offset = [e.clientX, e.clientY]; //��¼��ʼ����

                that.getCssRule(field, function(item){
                    var width = item.style.width || othis.outerWidth();
                    dict.rule = item;
                    dict.ruleWidth = parseFloat(width);
                    dict.minWidth = othis.data('minwidth') || options.cellMinWidth;
                });
            }
        });
        //��ק��
        _DOC.unbind('mousemove').on('mousemove', function(e){
            if(dict.resizeStart){
                e.preventDefault();
                if(dict.rule){
                    var setWidth = dict.ruleWidth + e.clientX - dict.offset[0];
                    if(setWidth < dict.minWidth) setWidth = dict.minWidth;
                    dict.rule.style.width = setWidth + 'px';
                    layer.close(that.tipsIndex);
                }
                resizing = 1
            }
        })
        _DOC.unbind('mouseup').on('mouseup', function(e){
            if(dict.resizeStart){
                dict = {};
                _BODY.css('cursor', '');
                that.scrollPatch();
            }
            if(resizing === 2){
                resizing = null;
            }
        });
        //����
        th.unbind('click').on('click', function(){//���������
            var othis = $(this)
                ,elemSort = othis.find(ELEM_SORT)
                ,nowType = elemSort.attr('lay-sort')
                ,type;

            if(!elemSort[0] || resizing === 1) return resizing = 2;

            if(nowType === 'asc'){
                type = 'desc';
            } else if(nowType === 'desc'){
                type = null;
            } else {
                type = 'asc';
            }
            that.sort(othis, type, null, true);
            table.query(that.key);//���²�ѯ
        })
        th.find(ELEM_SORT+' .layui-edge ').unbind('click').on('click', function(e){//���С������
            var othis = $(this)
                ,index = othis.index()
                ,field = othis.parents('th').eq(0).data('field')
            layui.stope(e);
            if(index === 0){
                that.sort(field, 'asc', null, true);
            } else {
                that.sort(field, 'desc', null, true);
            }
            table.query(that.key);//���²�ѯ
        });
        if(!that.eventsinitIsRun){
            that.eventsinit();
            that.eventsinitIsRun=true;
        }
        //ͬ��������
        that.layMain.unbind('scroll').on('scroll', function(){
            var othis = $(this)
                ,scrollLeft = othis.scrollLeft()
                ,scrollTop = othis.scrollTop();

            that.layHeader.scrollLeft(scrollLeft);
            that.layFilter.scrollLeft(scrollLeft);
            that.layFixed.find(ELEM_BODY).scrollTop(scrollTop);

            layer.close(that.tipsIndex);
        });
        _WIN.unbind('resize').on('resize', function(){ //����Ӧ
            that.resize();
        });
    };
    //�¼�������Ԫ��༭(ִֻ��һ��)
    Class.prototype.eventsinitIsRun=false;
    //ִֻ��һ�ε��¼�
    Class.prototype.eventsinit = function(){
        var that = this
            ,options = that.config
            ,ELEM_CELL = '.layui-table-cell'
            ,filter = options.elem.attr('lay-filter');
        //���ڹ���
        that.layFilter.on('keyup',"[name^='filter_']",function () {
            that.page=1;
            that.pullData(that.page, that.loading());
        });
        //���¼�
        that.layBody.on('mouseenter','tr',function(){
            var othis = $(this)
                ,index = othis.index();
            that.layBody.find('tr:eq('+ index +')').addClass(ELEM_HOVER)
        })
        that.layBody.on('mouseleave','tr', function(){
            var othis = $(this)
                ,index = othis.index();
            that.layBody.find('tr:eq('+ index +')').removeClass(ELEM_HOVER)
        });
        //��Ԫ���¼�
        that.layBody.on('click','td div.layui-table-cell p',function(){
            var othis = $(this).parent().parent()
                ,field = othis.data('field')
                ,editType = othis.data('edit')
                ,index = othis.parents('tr').eq(0).data('index')
                ,data = table.getDataList(that.key)[index]
                ,elemCell = othis.children(ELEM_CELL);
            var  options = that.config;
            layer.close(that.tipsIndex);
            if(othis.data('off')) return;

            //��ʾ�༭����
            if(editType){
                if(editType === 'select') { //ѡ���
                    var dropName=othis.data('drop');
                    var rowsField=dl.ui.table.drop.findFieldObj(options.cols[0],field);
                    var o=dl.cache.code.get(rowsField.drop);
                    var html='';
                    var scv=o.syscodevaluecache;
                    for(var i in scv){
                        var isSelected="";
                        if(scv[i].scv_value==data[field]){
                            isSelected="selected='selected'";
                        }
                        //ѡ��
                        html+='<option '+isSelected+'  value="'+scv[i].scv_value+'">'+scv[i].scv_show_name+'</option>'
                    }
                    var select = $('<select class="'+ ELEM_EDIT +'" lay-ignore>' +
                        html+
                        '</select>');
                    othis.find('.'+ELEM_EDIT)[0] || othis.append(select);
                } else { //�����
                    var input = $('<input class="layui-input '+ ELEM_EDIT +'">');
                    input[0].value = $.trim($(this).text());//  othis.data('content') || elemCell.text();
                    othis.find('.'+ELEM_EDIT)[0] || othis.append(input);
                    input.focus();
                }
                return;
            }

            //�������ʡ�ԣ���ɲ鿴����
            var c=that.getCols(field);

            if(!table.config.initWidth[c["type"]]){
                if(elemCell.find('.layui-form-switch,.layui-form-checkbox')[0]) return; //���Ʋ����ָ��ࣨ��ʱ��
                if(Math.round(elemCell.prop('scrollWidth')) > Math.round(elemCell.outerWidth())){
                    that.tipsIndex = layer.tips([
                        '<div class="layui-table-tips-main" style="margin-top: -'+ (elemCell.height() + 16) +'px;'+ function(){
                            if(options.size === 'sm'){
                                return 'padding: 4px 15px; font-size: 12px;';
                            }
                            if(options.size === 'lg'){
                                return 'padding: 14px 15px;';
                            }
                            return '';
                        }() +'">'
                        ,elemCell.html()
                        ,'</div>'
                        ,'<i class="layui-icon layui-table-tips-c">&#x1006;</i>'
                    ].join(''), elemCell[0], {
                        tips: [3, '']
                        ,time: -1
                        ,anim: -1
                        ,maxWidth: (device.ios || device.android) ? 300 : 600
                        ,isOutAnim: false
                        ,skin: 'layui-table-tips'
                        ,success: function(layero, index){
                            layero.find('.layui-table-tips-c').on('click', function(){
                                layer.close(index);
                            });
                        }
                    });
                }
            }
        });
        that.layBody.on('change','.'+ELEM_EDIT, function(){
            var othis = $(this)
                ,value = this.value
                ,field = othis.parent().data('field')
                ,index = othis.parents('tr').eq(0).data('index')
                ,data = table.getDataList(that.key)[index];
            data[field] = value; //���»����е�ֵ
            layui.event.call(this, MOD_NAME, 'edit('+ filter +')', {
                value: value
                ,data: data
                ,field: field
            });
        });
        that.layBody.on('blur','.'+ELEM_EDIT, function(){//��Ԫ��ʧȥ����
            var templet
                ,othis = $(this)
                ,field = othis.parent().data('field')
                ,index = othis.parents('tr').eq(0).data('index')
                ,editType = othis.parent().data('edit')
                ,data = table.getDataList(that.key)[index];
            var  options = that.config;
            that.eachCols(function(i, item){
                if(item.field == field && item.templet){
                    templet = item.templet;
                }
            });
            var value="";
            if(editType === 'select') { //ѡ���
                var rowsField=dl.ui.table.drop.findFieldObj(options.cols[0],field);
                if(rowsField&&rowsField['drop']){
                    var o=dl.cache.code.get(rowsField.drop);
                    value=dl.ui.table.drop.findDropLable(rowsField.drop,this.value);
                }
                othis.parent().find(ELEM_CELL+' p').html(
                    templet ? laytpl($(templet).html() || value).render(data) : value
                );
            } else {//�����
                othis.parent().find(ELEM_CELL+' p').html(
                    templet ? laytpl($(templet).html() || this.value).render(data) : this.value
                );
            }
            othis.parent().data('content', this.value);
            othis.remove();
        });
        //���νڵ����¼�������չ���¼��ڵ㣩
        that.elem.on('click','i.layui-tree-head', function(){
            var othis = $(this)
                ,index = othis.parents('tr').eq(0).data('index')
                ,options=that.config
                ,datas=table.getDataList(that.key);//����
            var o=datas[index];
            that.treeNodeOpen(o,!o[table.config.cols.isOpen]);
            that.resize();
        });
        //��ѡ��ѡ��
        that.elem.on('click','input[name="'+TABLE_CHECKBOX_ID+'"]+', function(){
            var checkbox = $(this).prev()
                ,childs = that.layBody.find('input[name="'+TABLE_CHECKBOX_ID+'"]')
                ,index = checkbox.parents('tr').eq(0).data('index')
                ,checked = checkbox[0].checked
                ,obj=table.getDataList(that.config.id)[index]
                ,isAll = checkbox.attr('lay-filter') === 'layTableAllChoose';
            //ȫѡ
            if(isAll){
                var list=table.getDataList(that.key);
                list.forEach(function (temo) {
                    if(!temo[table.config.cols.cheDisabled]){//����ѡ��Ĳ�����
                        that.setCheckData(temo[table.config.indexName], checked);
                    }
                });
            } else {
                that.setCheckData(index, checked);
                if(options.isTree){
                    //�����¼�
                    var sonList=that.treeFindSonData(obj);
                    sonList.forEach(function (temo) {
                        if(!temo[table.config.cols.cheDisabled]){//����ѡ��Ĳ�����
                            that.setCheckData(temo[table.config.indexName], checked);
                        }
                    });

                    //�����ϼ�
                    var temf=function (o) {
                        if(o==null)return;
                        if(o&&o.children.length>0){
                            var temis=true;
                            o.children.forEach(function (temo) {
                                if(!temo[table.config.cols.isCheckName]){
                                    temis=false;
                                }
                            });
                            if(temis){
                                that.setCheckData(o[table.config.indexName], checked);
                            }

                            var temuo=that.treeFindUpData(o);
                            if(temuo){
                                temf(temuo);
                            }
                        }
                    }
                    var uo=that.treeFindUpData(obj);
                    temf(uo);
                }
            }
            that.syncCheckAll();
            layui.event.call(this, MOD_NAME, 'checkbox('+ filter +')', {
                checked: checked
                ,data: table.getDataList(that.key) ? (obj || {}) : {}
                ,type: isAll ? 'all' : 'one'
            });
            typeof options.onCheck === 'function' && options.onCheck(obj,checked,isAll);
        });

        //��ѡ��ѡ��
        that.elem.on('click','input[name="'+TABLE_RADIO_ID+'"]+', function(){
            var checkbox = $(this).prev()
                ,index = checkbox.parents('tr').eq(0).data('index')
                ,obj=table.getDataList(that.config.id)[index];
            typeof options.onRadio === 'function' && options.onRadio(obj);
        });

        //�����������¼�
        that.layBody.on('click', '*[lay-event]',function(){
            var othis = $(this)
                ,index = othis.parents('tr').eq(0).data('index')
                ,tr = that.layBody.find('tr[data-index="'+ index +'"]')
                ,ELEM_CLICK = 'layui-table-click'
                ,list = table.getDataList(that.key)
                ,data = table.getDataList(that.key)[index];
            layui.event.call(this, MOD_NAME, 'tool('+ filter +')', {
                data: data//table.clearCacheKey(data)
                ,event: othis.attr('lay-event')
                ,tr: tr
                ,del: function(){
                    table.delRow(options.id,data);
                }
                ,update: function(fields){
                    fields = fields || {};
                    layui.each(fields, function(key, value){
                        if(key in data){
                            var templet, td = tr.children('td[data-field="'+ key +'"]');
                            data[key] = value;
                            that.eachCols(function(i, item2){
                                if(item2.field == key && item2.templet){
                                    templet = item2.templet;
                                }
                            });
                            td.children(ELEM_CELL).html(
                                templet ? laytpl($(templet).html() || value).render(data) : value
                            );
                            td.data('content', value);
                        }
                    });
                }
            });
            tr.addClass(ELEM_CLICK).siblings('tr').removeClass(ELEM_CLICK);
        });
    }
    //��������
    thisTable.config = {};
    //�Զ������Ⱦ
    table.init();
    // layui.link('treeGrid.css');
    exports(MOD_NAME, table);
});