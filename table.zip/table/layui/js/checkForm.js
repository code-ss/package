﻿function layui_alert(msg) {
    layui.use(['layer'], function () {
        var layer = layui.layer;

        layer.msg(msg);
    });
}
//判断输入框是否为空 参数：标签的id
function isNull(classId, content) {
    //var values = $("#" + classId + "").val().trim();
    var values = $("#" + classId + "").val().replace(" ", "");
    if (values == "" || values == null || values == undefined) {
        $("#" + classId + "").focus();
        layui_alert(content + "不能为空");
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
        return true;
    }


}
//提示框 参数：元素id，提示内容，校验返回值
function showInfo(classId) {
    var content = $("#check" + classId).val();
    var flag = $("#boo" + classId).val();
    if (flag == "false") {
        layui.use(['layer'], function () {
            var layer = layui.layer;
            layer.tips(content
                , '#' + classId
                , {
                    tips: 4
                });
        });
    }
}
//判断是否为相应的长度 标签的id
function isLength(classId, content, min, max) {
    var value = $("#" + classId + "").val();
    var boo1 = false;
    var boo2 = false;
    if (max == "-1") {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
        boo1 = true;
    } else {
        if (value.length > max) {
            layui_alert(content + "最多只能为 " + max + " 位");
            $("#" + classId + "").focus();
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            boo2 = false;
        } else {
            boo2 = true;
        }
    }
    if (min == "-1") {
        boo2 = true;
    } else {
        if (value.length < min) {
            layui_alert(content + "至少有 " + min + " 位");
            $("#" + classId + "").focus();
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            boo1 = false;
        } else {
            $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
            boo1 = true;
        }
    }
    return boo1 & boo2;
}

//纯汉字的校验 参数：输入框id，输入框名称， 最小位数，最大位数（-1为不做限制）
function checkAllCN(classId, content, min, max) {
    var isEmpty = isNull(classId, content);
    if (!isEmpty) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
    var isEnough = isLength(classId, content, min, max);
    if (!isEnough) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }

    var regepName = /^[\u4E00-\u9FA5\uf900-\ufa2d·s]$/;  //含有特殊字符的正则，false是不含，true为含有
    if (!$("#" + classId + "").val().match(regepName)) {
        layui_alert(content + "输入错误");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
}

//纯英文的校验 参数：输入框id，输入框名称， 最小位数，最大位数（-1为不做限制）
function checkAllEN(classId, content, min, max) {
    var isEmpty = isNull(classId, content);
    if (!isEmpty) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
    var isEnough = isLength(classId, content, min, max);
    if (!isEnough) {
        return false;
    }

    var regepName = /^[a-zA-Z]$/;  //含有特殊字符的正则，false是不含，true为含有
    if (!$("#" + classId + "").val().match(regepName)) {
        layui_alert(content + "输入错误");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }
}
/*function checkEnAndNum(classId,className){
 var
 }*/

//纯数字的校验 参数：输入框id，输入框名称， 最小位数，最大位数（-1为不做限制）
function checkAllNum(classId, content, min, max) {
    var isEmpty = isNull(classId, content);
    if (!isEmpty) {
        return false;
    }
    var isEnough = isLength(classId, content, min, max);
    if (!isEnough) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }

    //var regepName = /^[0-9]$/;  //含有特殊字符的正则，false是不含，true为含有
    var regepName = /^\+?[1-9][0-9]*$/; //含有特殊字符的正则，false是不含，true为含有
    if (!$("#" + classId + "").val().match(regepName)) {
        layui_alert(content + "输入错误,必须输入数字。");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }
}

//纯数字的校验 参数：输入框id，输入框名称， 最小位数，最大位数（-1为不做限制）
function checkAllTel(classId, content, min, max) {
    var isEmpty = isNull(classId, content);
    if (!isEmpty) {
        return false;
    }
    var regepName1 = /\b0\d{2,3}\b/;
    var regepName2 = /\b\d{5,7}\b/;
    var boo = regepName1.test($("#" + classId + "").val());
    var boo2 = regepName2.test($("#" + classId + "").val());
    if (min == 4) {
        if (boo) {
            $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
            return true;
        } else {
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            layui_alert(content + "输入错误，请输入正确的区号。");
            return false;

        }
    } else if (min == 7 || min == 5 || min == 8) {
        if (boo2) {
            var len = $("#" + classId + "").val().length;
            if (len == 7 || len == 8 || len == 5) {
                $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
                return true;
            } else {
                $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
                layui_alert(content + "输入错误，请输入正确的电话号码。");
                return false;
            }

        } else {
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            layui_alert(content + "输入错误，请输入正确的电话号码。");
            return false;
        }
    } else {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        layui_alert(content + "输入错误，请输入正确的电话号码。");
        return false;
    }
}
//校验手机号码
function checkPhones(classId, content) {
    var isEmpty = isNull(classId, content);
    //var valuse = $("#" + classId + "").val().trim();
    var valuse = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
    var regepName = /^1[3456789]\d{9}$/;
    if (!valuse.match(regepName)) {
        layui_alert(content + "输入错误");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }
}

//联系方式的校验 参数：输入框id
function checkTel(classId, content) {
    var isEmpty = isNull(classId, content);
    //var valuse = $("#" + classId + "").val().trim();
    var valuse = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
    var regepName = /((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)/;
    if (!valuse.match(regepName)) {
        layui_alert(content + "输入错误");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }
}


//邮箱的校验 参数：输入框id
function checkEmail(classId, content) {
    var isEmpty = isNull(classId, content);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    ;
    if (!isEmpty) {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }
    var regepName = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    ;
    if (!value.match(regepName)) {
        layui_alert(content + "输入错误");
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }
    //showInfo(classId);
}

//校验URL
function checkIsURL(classId) {
    var isEmpty = isNull(classId, content);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var regepName = "^((https|http|ftp|rtsp|mms)?://)"
        + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
        + "(([0-9]{1,3}\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
        + "|" // 允许IP和DOMAIN（域名）
        + "([0-9a-z_!~*'()-]+\.)*" // 域名- www.
        + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\." // 二级域名
        + "[a-z]{2,6})" // first level domain- .com or .museum
        + "(:[0-9]{1,4})?" // 端口- :80
        + "((/?)|" // a slash isn't required if there is no file name
        + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";
    var num = value.indexOf(".");
    if (!value.match(regepName) || num < 0) {
        layui_alert("请输入正确URL");
        $("#" + classId + "").focus();
        return false;
    } else {
        return true;
    }
}

//从字符串中提取数字
function getAllNum(classId) {
    var isEmpty = isNull(classId, content);
    if (!isEmpty) {
        return false;
    }
    var value = $("#" + classId + "").val();
    if (value == '无') {
        return value;
    } else {
        var num = value.replace(/[^0-9]/ig, "");
        return num;
    }
}
//是否含有中文（也包含日文和韩文）
function isChineseChar(elemenet, elementName) {
    var reg0 = /[\u4E00-\u9FA5\uF900-\uFA2D]/;//20190311sy停用
    var reg = /^[\u4e00-\u9fa5]+$/;
    var values = $("#" + elemenet).val();
    var flag = reg.test(values);
    if (values != "" && values != undefined) {
        if (flag) {
            return true;
        } else {
            layui_alert("只允许输入中文汉字作为元素中文名称，请检查！");
            return false;
        }
    } else {
        layui_alert("元素中文名称不能为空，请检查！");
    }

}

//验证名称是否存在非法的英文字符
function checkname(element, ele) {
    var flag = isNullName(element, ele);
    if (flag) {
        // var regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
        //技术性贸易壁垒（WTO/TBT）应对咨询
        /*var regEn = /[`~!@#$%^&*_+<>?:{};[\\]]/im,
         regCn = /[·！#￥：；|？【】[\]]/im;*/
        var regEn = /[`~!@#$%^&*_+<>?{}\/[\]]/im,
            regCn = /[！#￥|《》？【】[\]]/im;
        //var newName = $("#"+element).val().trim();
        var newName = $("#" + element).val().replace(" ", "");
        var text = regEn.test(newName) || regCn.test(newName);
        if (text) {
            layui_alert("该名称中含有英文的引号等特殊字符，请检查后重新填写。");
            $("#" + element).css({'border-width': '1px', 'border-color': 'red'});
            return false;
        } else {
            $("#" + element).css({'border-width': '1px', 'border-color': 'green'});
            return true;
        }
    } else {
        $("#" + element).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    }

}
//判断输入框是否为空 参数：标签的id
function isNullName(classId, classname) {
    //var values = $("#" + classId + "").val().trim();
    var values = $("#" + classId + "").val().replace(" ", "");
    if (values == "" || values == null || values == undefined) {
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        layui_alert(classname + "不能为空！");
        return false;
    } else {
        $("#" + classId).css({'border-width': '1px', 'border-color': 'green'});
        return true;
    }
}
//纯英文校验
function checkEnglish(classId, className) {
    var regepName = "^[A-Za-z]+$";
    var isEmpty = isNull(classId, className);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var num = value.length;
    if (!value.match(regepName) || num < 0) {
        layui_alert("请输入纯英文的" + className);
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }

}
//纯英文校验
function checkEnglishProtype(classId, className) {
    var regepName = "^[A-Za-z]+$";
    var isEmpty = isNull(classId, className);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var num = value.length;
    if (!value.match(regepName) || num < 0) {
        layui_alert("请输入纯英文的" + className);
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        return true;
    }

}
//登录账号的校验
function checkLoginAccount(classId, className, min, max) {
    var regepName = "^[0-9a-zA-Z]+$";
    var isEmpty = isNull(classId, className);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var num = value.length;
    if (!value.match(regepName) || num < 0) {
        layui_alert("请输入含有英文或者是数字的" + className);
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        if (value.length < min || value.length > max) {
            layui_alert("请输入" + min + "-" + max + "位的" + className);
            $("#" + classId + "").focus();
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            return false;
        } else {
            return true;
        }

    }

}
//登录密码的校验
function checkLoginPassword(classId, className, min, max) {
    var regepName = "^[0-9a-zA-Z]+$";
    var isEmpty = isNull(classId, className);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var num = value.length;
    if (!value.match(regepName) || num < 0) {
        layui_alert("请输入含有英文或者是数字的" + className);
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {
        if (value.length < min || value.length > max) {
            layui_alert("请输入" + min + "-" + max + "位的" + className);
            $("#" + classId + "").focus();
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            return false;
        } else {
            return true;
        }

    }

}
//登录密码的校验
function checkComplexLoginPassword(classId, className, min, max) {
    //var regepName = "^[0-9a-zA-Z]+$";
    var regepName = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{6,16}');

    var isEmpty = isNull(classId, className);
    //var value = $("#" + classId + "").val().trim();
    var value = $("#" + classId + "").val().replace(" ", "");
    if (!isEmpty) {
        return false;
    }
    var num = value.length;
    //alert(regepName.test(value));
    //if(!value.match(regepName)||num<0){
    if (value.length < min || value.length > max) {
        layui_alert("请输入" + min + "-" + max + "位的" + className);
        $("#" + classId + "").focus();
        $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
        return false;
    } else {

        if (!(regepName.test(value)) || num < 0) {
            layui_alert("请输入同时含有英文、数字、符号的" + className);
            $("#" + classId + "").focus();
            $("#" + classId).css({'border-width': '1px', 'border-color': 'red'});
            return false;
        } else {
            return true;
        }
    }


}
//查询当前传入字段的长度
function checkLength(classId, className, length) {
    var isEmpty = isNull(classId, className);
    if (!isEmpty) {
        return false;
    }
    if ($("#" + classId).val().length == length) {
        return true;
    } else {
        return false;
    }
}
function isCardNo(classId, className) {
    var isEmpty = isNull(classId, className);
    if (!isEmpty) {
        return false;
    }
    var values = $("#"+classId).val();
    // 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if (reg.test(values) === false) {
        layui_alert("身份证输入不合法");
        return false;
    }else{
        return true;
    }
}