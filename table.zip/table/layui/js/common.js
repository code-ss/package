/****
 * 初始封装layui的ajax请求的js文件（后续可添加）
 * @author 朱伟超 2019-04-03 创建
 */
var lU = {};
var laydate;
var laypage;
var $ ;
var form ;
var layer ;
var laydate;
var table;
var carousel;
var element;
var slider;
lU.ready=function(){};

layui.use(['laydate', 'laypage', 'layer', 'table', 'carousel', 'upload', 'element', 'slider','form'], function () {
         laydate = layui.laydate ;//日期
         laypage = layui.laypage ;//分页
         layer = layui.layer ;//弹层
         table = layui.table; //表格
         carousel = layui.carousel; //轮播
         upload = layui.upload ;//上传
         element = layui.element ;//元素操作
         slider = layui.slider ;//滑块
         $ = layui.jquery;
         form = layui.form;
         lU.ready();
});

lU.queryNullStr='没有查询到数据!<i class="layui-icon" style="font-size: 15px; color: '+lU.defaultColor+';">&#xe615;</i>';//没有查询到数据时显示的
lU.queryNullAlign="center";////没有查询到数据时显示的方式

lU.ajaxInit = {
    url : "",
    type : 'post',
    data : {},
    dataType : "json",
    async: true,
    success : function(r) {

    },
    error : function(XMLHttpRequest, textStatus, errorThrown) {
        lU.error(XMLHttpRequest);
    }
};


lU.ajax = function(ajaxUrl, ajaxData,fun) {
    var layer = layui.layer;
    $ = layui.jquery;
    lU.ajaxInit.url = ajaxUrl;
    lU.ajaxInit.data = ajaxData;
    lU.ajaxInit.success=fun
    $.ajax(lU.ajaxInit);
};

lU.ajaxAsync = function(ajaxUrl, ajaxData,fun,boo) {
    var layer = layui.layer;
    $ = layui.jquery;
    lU.ajaxInit.async=boo;
    lU.ajaxInit.url = ajaxUrl;
    lU.ajaxInit.data = ajaxData;
    lU.ajaxInit.success=fun;
    $.ajax(lU.ajaxInit);
};